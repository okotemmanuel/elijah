
import { Component, ViewChild, ElementRef , NgZone} from '@angular/core';
import { NavController ,LoadingController ,ToastController, Platform} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
 
import { SetlocPage } from '../setloc/setloc';
import { TrackPage } from '../track/track';

import { HomePage } from '../home/home';
import { AuthServiceProvider } from '../../providers/service/service';
import { Storage } from '@ionic/storage';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import {Observable} from 'rxjs';
declare var google: any;
/**
 * Generated class for the RequesttPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-requestt',
  templateUrl: 'requestt.html',
})
export class RequesttPage {
 
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  autocomplete: any;
  GoogleAutocomplete: any;
  GooglePlaces: any;
  geocoder: any ;
  autocompleteItems: any;
  nearbyItems: any = new Array<any>();
  loading: any;
  markers: any;
  locationn:String = '';

 constructor(
    public zone: NgZone,private authservice : AuthServiceProvider,private storage: Storage ,
    public loadingCtrl: LoadingController,private platform:Platform,private locationAccuracy: LocationAccuracy,
    public navCtrl: NavController, public geolocation: Geolocation ,public toastCtrl: ToastController
  ) {
    this.markers = [];
  
    this.geocoder = new google.maps.Geocoder;
    let elem = document.createElement("div")
    this.GooglePlaces = new google.maps.places.PlacesService(elem);
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
    this.autocomplete = {
      input: ''
    };
    this.autocompleteItems = [];
    this.loading = this.loadingCtrl.create();
     //this.loadMap();
     platform.ready().then(() => {
     
    });
    this.getid();
    this.getp();
}




 ionViewDidLoad(){
    this.initMap();
  }


  initMap() {
    this.map = new google.maps.Map(this.mapElement.nativeElement, {
      zoom: 13,
      center: {lat: 0.3476, lng: 32.5825}
    });

    this.directionsDisplay.setMap(this.map);
     // this.calculateAndDisplayRoute();
  }






pplac:string='loading';
dplac:string='loading';
ob:any=[];
dire:any;


getp(){
  var t=1;
    this.ob = Observable.interval(20 * 60).subscribe(x => {
  this.pplac = this.authservice.place();
  this.dplac = this.authservice.dlace();

  if(t==5){
 this.ob.unsubscribe();
 this.calculateAndDisplayRoute();
  }else{
t++;
  console.log('--------------'+this.pplac , this.dplac);
  }
    });
}


 directionsService = new google.maps.DirectionsService;
  directionsDisplay = new google.maps.DirectionsRenderer;
 calculateAndDisplayRoute() {
    this.directionsService.route({
      origin: this.pplac,
      destination: this.dplac,
      travelMode: 'DRIVING'
    }, (response, status) => {
      if (status === 'OK') {
        this.directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }





  








 mess:string;
indexxt:string;
getid(){
  this.storage.get('index').then((val) => {
    console.log('indexs = ', val);
    this.indexxt = val;
    this.presentToast('id = '+this.indexxt);
  })
}




LastLat:String;
LastLng: String;
setloc(){
   this.locationn = '';
}



 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 3000
    });
    toast.present();
  }


set(){
  this.navCtrl.push(SetlocPage);
}

pick(){
  this.navCtrl.push(SetlocPage);
}

drop(){
  this.navCtrl.push(HomePage);
}






cash:any=[];

obw:any;
data:any;
indexx:boolean=false;
req:boolean=true;
set2(){
  this.cash[0] = 'loading';
  this.cash[1] = 'loading';
  this.cash[2] = 'loading';
  this.cash[3] = 'loading';
 this.obw = Observable.interval(20 * 60).subscribe(x => {
 this.data = this.authservice.getdist().subscribe(
      (response) => console.log(this.cash = response),
      (error) =>console.log(error)
    );
    if(this.cash.length >  1){
    this.authservice.setcash(this.cash[1]);
  this.diactw();
 
   this.indexx = true;
   this.req=false;
    }else{
     
    }
  });
}

diactw(){
this.obw.unsubscribe();
}
cancl(){
    this.indexx = false;
   this.req= true;
}

myType:string='cash';

okay(){
    if(this.myType=='credit'){
    //console.log(this.myType , this.cash[2] );
    this.authservice.yom(this.myType , this.cash[2]);
    }else{
    this.authservice.yom(this.myType , this.cash[1]);
    }
    this.navCtrl.push(TrackPage);
}

}