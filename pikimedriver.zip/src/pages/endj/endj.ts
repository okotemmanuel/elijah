import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,LoadingController} from 'ionic-angular';
import {Observable} from 'rxjs'
/**
 * Generated class for the EndjPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import { AuthServiceProvider } from '../../providers/service/service';
import { HomePage } from '../home/home';
@IonicPage()
@Component({
  selector: 'page-endj',
  templateUrl: 'endj.html',
})
export class EndjPage {

  constructor(public loadingCtrl: LoadingController,private authservice : AuthServiceProvider,public navCtrl: NavController, public navParams: NavParams) {
      this.getdata();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EndjPage');
  }

data:any=[];
getdata(){
 this.data = this.authservice.getdata();
 
}
ob:any=[];
  set(){
      this.authservice.endj(this.data[0]).subscribe(
      (response) => response,
      (error) =>console.log(error)
 );
 const loader = this.loadingCtrl.create({
      content: "Please Wait...",
      duration: 100000
    });
    loader.present();

this.ob = Observable.interval(20 * 60).subscribe(x => {
   this.data = this.authservice.funn();
   console.log('received', this.data);


   if(this.data.length ===1 || this.data.length ===0){ 
     this.ob.unsubscribe();
      loader.dismiss();
      this.diact();
this.navCtrl.push(HomePage);

   }else{
    
   }
  });
}

diact(){
this.ob.unsubscribe();
 //this.index = false ;
}

}


