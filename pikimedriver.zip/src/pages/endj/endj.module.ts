import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EndjPage } from './endj';

@NgModule({
  declarations: [
    EndjPage,
  ],
  imports: [
    IonicPageModule.forChild(EndjPage),
  ],
})
export class EndjPageModule {}
