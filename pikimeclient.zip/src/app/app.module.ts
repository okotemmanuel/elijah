import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { LoginPage } from '../pages/login/login';
import { ProfilePage } from '../pages/profile/profile';
import { ChatPage } from '../pages/chat/chat';
import { PayinfoPage } from '../pages/payinfo/payinfo';
import { ServicesPage } from '../pages/services/services';
import { ContactPage } from '../pages/contact/contact';

import { SignupPage } from '../pages/signup/signup';
import { Geolocation } from '@ionic-native/geolocation';

import { ConnectPage } from '../pages/connect/connect';

import { SetlocPage } from '../pages/setloc/setloc';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import { Facebook } from '@ionic-native/facebook';

import { AuthServiceProvider } from '../providers/service/service';
import { HttpModule } from '@angular/http';

import { VerifPage } from '../pages/verif/verif';
import { EditprofPage } from '../pages/editprof/editprof';

import { GooglePlus } from '@ionic-native/google-plus';
import firebase from 'firebase';
import { AddtelPage } from '../pages/addtel/addtel';
import { JstartPage } from '../pages/jstart/jstart';
import { PayPage } from '../pages/pay/pay';
import { Ionic2RatingModule } from 'ionic2-rating';

import { TransferPage } from '../pages/transfer/transfer';

import { RequesttPage } from '../pages/requestt/requestt';
import { TrackPage } from '../pages/track/track';
import { InAppBrowser } from '@ionic-native/in-app-browser';

import { HttpClientModule } from '@angular/common/http';
import { Diagnostic } from '@ionic-native/diagnostic';

import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule, AngularFireDatabase } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';

export const firebaseConfig = {
    apiKey: "AIzaSyDtTdiifOlqTk8U1fXwbZE7ED57Y_3W-lw",
    authDomain: "pikime-c3611.firebaseapp.com",
    databaseURL: "https://pikime-c3611.firebaseio.com",
    projectId: "pikime-c3611",
    storageBucket: "pikime-c3611.appspot.com",
    messagingSenderId: "149912902895"    

    
}

import { IonicStorageModule } from '@ionic/storage';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    LoginPage,
    ProfilePage,
    ChatPage,
    PayinfoPage,
    ServicesPage,
    ContactPage,
    SignupPage,
    SetlocPage,
    VerifPage,
    EditprofPage,
    AddtelPage,
    JstartPage,
    PayPage,
    TransferPage,
    RequesttPage,
    TrackPage,
    ConnectPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot(),
    HttpClientModule,
 AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    AngularFireAuthModule

  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    LoginPage,
    ProfilePage,
    ChatPage,
    PayinfoPage,
    ServicesPage,
    ContactPage,
    SignupPage,
    SetlocPage,
    VerifPage,
    EditprofPage,
    AddtelPage,
    JstartPage,
    PayPage,
    TransferPage,
    RequesttPage,
    TrackPage,
    ConnectPage
  ],
  providers: [
    StatusBar,Diagnostic,
    SplashScreen,Facebook ,GooglePlus ,LocationAccuracy,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    Geolocation,InAppBrowser,
    AuthServiceProvider
  ]
})
export class AppModule {}
