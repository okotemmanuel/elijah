
import { Component ,ViewChild} from '@angular/core';
import { Nav , IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';
import { LoginPage } from '../login/login';
/**
 * Generated class for the EditprofPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
 import { AuthServiceProvider } from '../../providers/service/service';
 import {FormGroup, FormBuilder ,FormControl} from "@angular/forms";
import { Storage } from '@ionic/storage';
import {Observable} from 'rxjs';

@IonicPage()
@Component({
  selector: 'page-addtel',
  templateUrl: 'addtel.html',
})
export class AddtelPage {
  @ViewChild(Nav) nav: Nav;
myForm: FormGroup;
userInfo: {name: string } = {name: ''};

  constructor(private storage: Storage ,private authservice : AuthServiceProvider ,public formBuilder: FormBuilder , public navCtrl: NavController, public navParams: NavParams) {
this.getid();  

}

  ionViewDidLoad() {
    console.log('ionViewDidLoad EditprofPage');
  }


  ngOnInit(): any {
    this.myForm = this.formBuilder.group({
      'name': new FormControl(),
    })
  }

  
editp(){

}
tel:string;
num:string;
tomm:any;
indexx:any;
t:number=0;
tommm:string;
gettel(){
  this.tel = this.authservice.tomget();
  
  return this.tel;
}
mess='';
tom:string;
 onSubmit() {
   if(this.myForm.value.name === null || this.myForm.value.name.length !== 12){
this.mess='incorrect telephone number (eg 256779815657)';
   }else{
  //this.tel = this.authservice.tomget();
this.num = this.myForm.value.name;
this.tell =this.tel.replace(/"([^"]+(?="))"/g, '$1');
console.log(this.tell + ' - ' +this.num);
 this.authservice.updatel(this.tell ,this.num).subscribe((response) =>console.log(this.tom = response),(error) =>console.log(error)) ;
 console.log(this.tom);
this.store();


   }


}
id:number;
tell:string;
hop=[];
okk:any;
getid(){
this.tell = this.gettel();
this.tell =this.tel.replace(/"([^"]+(?="))"/g, '$1');
 this.okk = Observable.interval(20 * 60).subscribe(x => {
   console.log('ttttttttttttttt-'+this.tell);
  this.authservice.getid(this.tell).subscribe((response) =>this.id = response,(error) =>console.log(error)) ;
  if(this.id ==null || this.id==undefined || this.id == 0 ){

  }else{
    this.id = this.id ;
     this.authservice.idex(this.id)
this.okk.unsubscribe();
  }
 
});
  return this.id;  
}
ob:any=[];
mess2:string;
store(){
    this.authservice.idex(this.id);
    console.log('hell --- '+this.id);
    this.storage.set('index', this.id);
    var t=0;
    this.ob = Observable.interval(20 * 60).subscribe(x => {
    this.storage.get('index').then((val) => {
    console.log('indexs = ', val);
    this.indexx = val;
this.mess2= this.indexx ;

if(this.indexx===null  ){
    this.storage.set('index', this.id);
 }else{
if(t==1){
   this.mess2 = t.toString();
this.diact();
this.navCtrl.push(HomePage);
}else{
this.storage.set('index', this.id);
t++;
  this.mess2 = t.toString();
}
  }});});
  //this.mess2 ='ok';
}


diact(){
this.ob.unsubscribe();
}

}