import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { LoginPage } from '../pages/login/login';
import { ProfilePage } from '../pages/profile/profile';
import { ChatPage } from '../pages/chat/chat';
import { PayinfoPage } from '../pages/payinfo/payinfo';
import { ServicesPage } from '../pages/services/services';
import { ContactPage } from '../pages/contact/contact';

import { SignupPage } from '../pages/signup/signup';
import { Geolocation } from '@ionic-native/geolocation';

import { SetlocPage } from '../pages/setloc/setloc';
import { LocationAccuracy } from '@ionic-native/location-accuracy';


import { AuthServiceProvider } from '../providers/service/service';
import { HttpModule } from '@angular/http';

import { VerifPage } from '../pages/verif/verif';
import { EditprofPage } from '../pages/editprof/editprof';

import { BackgroundMode } from '@ionic-native/background-mode';
import { AddtelPage } from '../pages/addtel/addtel';
import { TransferPage } from '../pages/transfer/transfer';

import { LocalNotifications } from '@ionic-native/local-notifications';
//import { AngularFireAuthModule} from 'angularfire2/auth';

import { CallPage } from '../pages/call/call';
import { EndjPage } from '../pages/endj/endj';
import { NativeAudio } from '@ionic-native/native-audio';
//import { InAppBrowser } from "@ionic-native/in-app-browser";
import { IonicStorageModule } from '@ionic/storage';
import { Vibration } from '@ionic-native/vibration';
import { CallNumber } from '@ionic-native/call-number';
@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    LoginPage,
    ProfilePage,
    ChatPage,
    PayinfoPage,
    ServicesPage,
    ContactPage,
    SignupPage,
    SetlocPage,
    VerifPage,
    EditprofPage,
    AddtelPage,
    CallPage,
    EndjPage,
    TransferPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot(),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    LoginPage,
    ProfilePage,
    ChatPage,
    PayinfoPage,
    ServicesPage,
    ContactPage,
    SignupPage,
    SetlocPage,
    VerifPage,
    EditprofPage,
    AddtelPage,
    CallPage,
    EndjPage,
    TransferPage
  ],
  providers: [
    StatusBar,
    LocalNotifications,CallNumber,
    SplashScreen,LocationAccuracy,Vibration,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    Geolocation,NativeAudio,
    AuthServiceProvider,BackgroundMode
  ]
})
export class AppModule {}
