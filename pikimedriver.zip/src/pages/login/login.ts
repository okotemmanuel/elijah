import { Component , ViewChild } from '@angular/core';
import {Nav,IonicPage, NavController, NavParams , AlertController ,ToastController ,MenuController ,LoadingController} from 'ionic-angular';

//import { SignupPage } from '../signup/signup';
import { HomePage } from '../home/home';
import { Geolocation } from '@ionic-native/geolocation';


 import { LocationAccuracy } from '@ionic-native/location-accuracy';

 import {FormGroup, FormBuilder ,FormControl} from "@angular/forms";

 import { AuthServiceProvider } from '../../providers/service/service';

import { VerifPage } from '../verif/verif';
import { AddtelPage } from '../addtel/addtel';



import {Observable} from 'rxjs';
import { Storage } from '@ionic/storage';


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  @ViewChild(Nav) nav: Nav;
  displayName: any;
  email: any;
  familyName: any;
  givenName: any;
  userId: any;
  imageUrl: any;
  isLoggedIn:boolean = false;
  country:Number;
  userData: any;

myForm: FormGroup;
userInfo: {number: string, zip: number, pwd:string} = {number: '', zip:256 , pwd: '',};

//User:Observable<firebase.User>;

  constructor(
    //private afAuth:AngularFireAuth,
    public loadingCtrl: LoadingController,
    public storage: Storage,private menu: MenuController,
    //private platform:Platform,private iab: InAppBrowser ,
     private authservice : AuthServiceProvider ,public formBuilder: FormBuilder,public toastCtrl: ToastController, private locationAccuracy: LocationAccuracy ,public navCtrl: NavController, public navParams: NavParams ,  public geolocation: Geolocation ,public alertCtrl: AlertController) {
    this.locat();
    this.check('0');
   // this.User = this.afAuth.authState;
  }


  ngOnInit(): any {
    this.myForm = this.formBuilder.group({
      'number': new FormControl(),
      'zip': new FormControl(),
       'pwd': new FormControl(),
    })
  }

num :String;
yop :String;  
t:number=0;
mess:string;

tt:number=0;
ob:any=[];
  onSubmit() {
this.num = this.myForm.value.zip + this.myForm.value.number ;
console.log('tom '+this.num ,this.myForm.value.pwd );
 //this.navCtrl.push(HomePage);
 this.mess = '';
if(this.myForm.value.number === null || this.myForm.value.pwd === null || this.myForm.value.number.length !== 9){
this.mess = 'incorrect telephone number (eg 779815657)';
console.log(this.mess);
}else{
    this.mess = '';
     const loader = this.loadingCtrl.create({
      content: "Logining In ...",
      duration: 100000
    });
    loader.present();
var t=0
     this.ob = Observable.interval(20 * 60).subscribe(x => {
   this.authservice.clogin(this.num ,this.myForm.value.pwd).subscribe(
      (response) => console.log(this.data = response),
      (error) =>console.log(error)
    );

if(t===4){
    if(this.data[0] ==undefined || this.data[0] =='0'){
      this.mess = 'incorrect login creditials , Ensure your Signedup';
        loader.dismiss();
    }else{
      this.mess = '';
      console.log('tom --',this.data[0]);
      this.storage.set('index',this.data[0]);
      this.authservice.idex(this.data[0]);
      
           loader.dismiss();
  
     if(this.diact() ===1 ){
   this.navCtrl.push(HomePage);
     }else{
 this.diact();
     }
 
    }
this.ob.unsubscribe();  
 this.diact();
}
else{
t++;
console.log('t - -', t );
}
  });
  
 
}


}




data:any=[];
fbb:string;
tommm:String ='0';

diact(){
this.ob.unsubscribe();
return 1;
}

ionViewDidEnter() {
    this.menu.swipeEnable(false);
  }

  ionViewWillLeave() {
    this.menu.swipeEnable(true);
   }


check(numb){
    this.authservice.check(numb).subscribe(
      (response) => this.tommm = response,
      (error) =>console.log(error)
    ) ;
    console.log(this.tommm);
    return this.tommm ;
  }
to:string;
fb(email,name,pic){
    this.authservice.fblogin(email,name,pic).subscribe(
      (response) => this.fbb = response,
      (error) =>console.log(error)
    ) ;

this.storage.set('index', this.fbb);

    //console.log(this.tomm);
    return this.to;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }



locat(){
  this.locationAccuracy.canRequest().then((canRequest: boolean) => {

  if(canRequest) {
    // the accuracy option will be ignored by iOS
    this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      () => console.log('Request successful'),
      error => console.log('Error requesting location permissions', error)
    );
  }

});
}
indexxs:any;
ind:string;

store(ids){
    this.storage.set('index',ids);
   this.indexxs = this.storage.get('index');
  console.log('index = ',JSON.stringify(this.indexxs));
 this.storage.get('index').then((val) => {
   this.ind = val;
    return this.ind;
  });
  
}



 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 3000
    });
    toast.present();
  }









tom:number;
}
