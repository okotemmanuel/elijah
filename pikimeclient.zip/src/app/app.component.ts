import { Component, ViewChild } from '@angular/core';
import { Nav, Platform ,ToastController} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';

import { LoginPage } from '../pages/login/login';
import { ProfilePage } from '../pages/profile/profile';
import { ChatPage } from '../pages/chat/chat';
import { PayinfoPage } from '../pages/payinfo/payinfo';
import { ServicesPage } from '../pages/services/services';
import { ContactPage } from '../pages/contact/contact';
import { TransferPage } from '../pages/transfer/transfer';

import { Storage } from '@ionic/storage';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any;

  pages: Array<{title: string, component: any}>;
n:any;
  constructor(public toastCtrl: ToastController ,private storage: Storage ,public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen) {
    this.initializeApp();
this.n = this.storage.get('index').then((val) => {
    console.log('indexs = ', val);
this.indexx = val;
   // 

    if(val ==null){
     this.rootPage =LoginPage;
      this.presentToast('val is null');
    }else{
     this.rootPage =HomePage;
      this.presentToast('val is' +val);
      //this.nav.setRoot(HomePage);
    }
    return this.indexx;
  });
//this.presentToast(JSON.stringify(this.n));
    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Profile', component: ProfilePage },
      { title: 'Home', component: HomePage },
      { title: 'Payment/Account', component: PayinfoPage },
      { title: 'Credit share', component: TransferPage },
      { title: 'Services', component: ServicesPage },
      { title: 'SOS', component: ListPage },
      { title: 'Save address', component: ListPage },
      { title: 'Contact Us', component: ContactPage },
      { title: 'Logout', component:LoginPage }
    ];

  }

 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 3000
    });
    toast.present();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
indexx:any;
r:any;
  openPage(page) {
    // Reset the content nav to have just this page
console.log('index = ', this.indexx);

  if(page.component == LoginPage){
    
  if(this.indexx == null){
this.nav.setRoot(page.component);
  }else{
    this.r = this.storage.remove('index');
    console.log();
    this.nav.setRoot(LoginPage);
  }
  }else{
    this.nav.setRoot(page.component);
  }
    
  }
}
