import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,AlertController} from 'ionic-angular';

/**
 * Generated c+lass for the TransferPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import { HomePage } from '../home/home';
import { AuthServiceProvider } from '../../providers/service/service';
import {Observable} from 'rxjs';
import {FormGroup, FormBuilder ,FormControl} from "@angular/forms";

/**
 * Generated class for the TopupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-topup',
  templateUrl: 'topup.html',
})
export class TopupPage {

myForm: FormGroup;
userInfo: {tel: string, amount: string } = {tel: '', amount:''};

  constructor(public alertCtrl: AlertController , private authservice : AuthServiceProvider,public formBuilder: FormBuilder , public navCtrl: NavController, public navParams: NavParams) {
this.get();
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad TopupPage');
  }


  ngOnInit(): any {
    this.myForm = this.formBuilder.group({
      'tel': new FormControl(),
      'amount': new FormControl(),
    })
  }


ob:any=[];
data:any=[];
bal:any=[];
mess:string;
t:number=0;

num:string;
tell:string;
amount:string;

onSubmit() {
  
 console.log('tom ---' ,this.myForm.value.tel , this.myForm.value.amount);
 //this.pay(this.myForm.value.tel ,this.myForm.value.amount );
this.tell = this.myForm.value.tel;
this.amount = this.myForm.value.amount ;
this.showConfirm();
}




pay(){
    if(this.t==0){
  this.data = this.authservice.topup(this.tell,this.amount).subscribe((response) =>this.bal = response,(error) =>console.log(error));
  //this.mess ='SUCCESSFULLY SENT';
  this.ob = Observable.interval(20 * 60).subscribe(x => {
 if(this.bal.length < 1 || this.bal==undefined || this.bal==null){ 
   }else{
       if(this.bal=='1'){
   this.mess ='SUCCESSFULLY SENT';
    this.t=1;
   this.diact();
       }
else if(this.bal=='0'){
this.mess ='ERROR insufficient balance Or Tell is not registered';
 //this.diact();
       }
       else{
         this.mess='unknown eror';
        //  this.diact();
       }
     console.log(this.bal);         
      }
   })
}else{
   this.mess ='ALREADY SENT';
}

}

diact(){
this.ob.unsubscribe();
}
done(){
   this.navCtrl.push(HomePage);
}



  showConfirm() {
    const confirm = this.alertCtrl.create({
      title: 'CONFRIRMATION',
      message: 'Do you agree to TOP UP  '+this.amount+' to '+this.tell , 
      buttons: [
        {
          text: 'Cancel',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Okay',
          handler: () => {
            this.pay();
          }
        }
      ]
    });
    confirm.present();
  }


  indexx:any;
  tom:any=[];
datas:any=[];
obs:any=[];
index2:boolean=false;
get(){
 this.obs = Observable.interval(20 * 60).subscribe(x => {
  this.datas = this.authservice.getprof().subscribe((response) =>this.tom = response,(error) =>console.log(error));
   if(this.tom.length < 1 || this.tom ===undefined || this.tom===null){ 
   }else{
        this.diacts();
        this.index2=true;
        this.userInfo.tel = this.tom[2] ;
        console.log('reced', this.tom);
   }
  });
}

diacts(){
this.obs.unsubscribe();
}





}
