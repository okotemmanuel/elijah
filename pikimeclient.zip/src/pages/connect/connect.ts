import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,LoadingController } from 'ionic-angular';
import { Observable } from 'rxjs';
import { AuthServiceProvider } from '../../providers/service/service';
import { JstartPage } from '../jstart/jstart';
/**
 * Generated class for the ConnectPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import { TrackPage } from '../track/track';
@IonicPage()
@Component({
  selector: 'page-connect',
  templateUrl: 'connect.html',
})
export class ConnectPage {
hnumb:number;
  constructor(public navCtrl: NavController,private authservice : AuthServiceProvider,  public loadingCtrl: LoadingController,public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ConnectPage');
  }

funr(){
  console.log('-----'+this.hnumb);
  this.authservice.hnumset(this.hnumb);
  this.navCtrl.push(TrackPage);
}



}
