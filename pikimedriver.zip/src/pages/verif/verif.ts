import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the VerifPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

import { HomePage } from '../home/home';
import { AuthServiceProvider } from '../../providers/service/service';
import {FormGroup, FormBuilder ,FormControl} from "@angular/forms";


@IonicPage()
@Component({
  selector: 'page-verif',
  templateUrl: 'verif.html',
})
export class VerifPage {

myForm: FormGroup;
userInfo: {code: string} = {code: ''};
mess:string;

  constructor(public formBuilder: FormBuilder ,private authservice : AuthServiceProvider ,public navCtrl: NavController, public navParams: NavParams) {
    this.getcode();
  }

    ngOnInit(): any {
    this.myForm = this.formBuilder.group({
      'code': new FormControl()
    })
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad VerifPage');
  }

num:string;

  onSubmit() {
this.num = this.myForm.value.code;
console.log(this.num);

if(this.num === this.code){
  this.mess= 'correct';
  this.navCtrl.push(HomePage);
}else{
this.mess= 'incorrect verification code';
}

console.log(this.code);
}

editp(){
  this.navCtrl.push(HomePage);
}

tel:string;
gettel(){
  this.tel = this.authservice.tomget();
  return this.tel;
}

code:string;
tell:string;
hop=[];

getcode(){
this.tell = this.gettel();
console.log('tell = '+this.tell);
  this.authservice.vcode(this.tell).subscribe((response) => console.log(this.code = response),(error) =>console.log(error)) ;
 // console.log('code ='+this.code);
  return this.code;  
}


}
