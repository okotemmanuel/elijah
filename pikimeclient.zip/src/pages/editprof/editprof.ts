import { Component , ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Nav } from 'ionic-angular';
import { HomePage } from '../home/home';
import { LoginPage } from '../login/login';
/**
 * Generated class for the EditprofPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
 import { AuthServiceProvider } from '../../providers/service/service';
 import {FormGroup, FormBuilder ,FormControl} from "@angular/forms";
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-editprof',
  templateUrl: 'editprof.html',
})

export class EditprofPage {
  @ViewChild(Nav) nav: Nav;

myForm: FormGroup;
userInfo: {name: string, email: string } = {name: '', email:''};

  constructor(private storage: Storage ,private authservice : AuthServiceProvider ,public formBuilder: FormBuilder , public navCtrl: NavController, public navParams: NavParams) {
this.getid();  

}

  ionViewDidLoad() {
    console.log('ionViewDidLoad EditprofPage');
  }


  ngOnInit(): any {
    this.myForm = this.formBuilder.group({
      'name': new FormControl(),
      'email': new FormControl(),
    })
  }

  
editp(){

}
tel:string;
num:string;
tomm:any;
indexx:any;
t:number=0;

gettel(){
  this.tel = this.authservice.tomget();
  return this.tel;
}

 onSubmit() {
  this.tel = this.authservice.tomget();
this.num = this.myForm.value.name + this.myForm.value.email;
//console.log(this.num + ' - ' +this.tel);
this.authservice.pinfo(this.tel ,this.myForm.value.name ,this.myForm.value.email ).subscribe((response) =>this.id = response,(error) =>console.log(error)) ;
this.store();

}

id=[];
tell:string;
hop=[];

getid(){
this.tell = this.gettel();
  this.authservice.getid(this.tell).subscribe((response) =>this.id = response,(error) =>console.log(error)) ;
  this.authservice.idex(this.id);
  return this.id;  
}

store(){
  this.authservice.idex(this.id);
    this.storage.set('index', this.id);
   this.indexx = this.storage.get('index');
   if(this.indexx ===null){
this.navCtrl.push(LoginPage);
   }else{
this.navCtrl.push(HomePage);
   }
  console.log('index = ',this.indexx);
}


}