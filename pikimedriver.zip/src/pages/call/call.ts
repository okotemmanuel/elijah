import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CallNumber } from '@ionic-native/call-number';
/**
 * Generated class for the CallPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import { AuthServiceProvider } from '../../providers/service/service';
import { EndjPage } from '../endj/endj';

@IonicPage()
@Component({
  selector: 'page-call',
  templateUrl: 'call.html',
})
export class CallPage {

  constructor(private callNumber: CallNumber, private authservice : AuthServiceProvider,public navCtrl: NavController, public navParams: NavParams) {
    this.getdata();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CallPage');
  }
data:any=[];
getdata(){
 this.data = this.authservice.getdata();
 console.log(this.data[0][3] , this.data[0]);
}


num:string;
call(){
  this.num = '+'+this.data[5];
  console.log('-'+this.num+'-');
 this.callNumber.callNumber( this.num , true);
}

set(){
this.authservice.startj(this.data[0]).subscribe(
      (response) => response,
      (error) =>console.log(error)
 );
this.navCtrl.push(EndjPage);
}

}
