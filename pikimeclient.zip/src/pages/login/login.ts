import { Component , ViewChild } from '@angular/core';
import {Nav,IonicPage, NavController, NavParams , AlertController ,ToastController ,MenuController} from 'ionic-angular';

//import { SignupPage } from '../signup/signup';
import { HomePage } from '../home/home';
import { Geolocation } from '@ionic-native/geolocation';

import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook';

import { GooglePlus } from '@ionic-native/google-plus';
 import { LocationAccuracy } from '@ionic-native/location-accuracy';

 import {FormGroup, FormBuilder ,FormControl} from "@angular/forms";

 import { AuthServiceProvider } from '../../providers/service/service';

import { VerifPage } from '../verif/verif';
import { AddtelPage } from '../addtel/addtel';

import { AngularFireModule } from 'angularfire2';
import firebase from 'firebase' ;
import { Observable } from 'rxjs';
//import firebase from 'firebase';
import { AngularFireAuth } from 'angularfire2/auth';
import { Platform } from 'ionic-angular';
///import {Observable} from 'rxjs/Observable'; 

import { InAppBrowser } from "@ionic-native/in-app-browser";
import { Storage } from '@ionic/storage';
import { Diagnostic } from '@ionic-native/diagnostic';

//, InAppBrowserEvent
/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
//@Injectable()
@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
    //diagnostic: any;
  @ViewChild(Nav) nav: Nav;
  displayName: any;
  email: any;
  familyName: any;
  givenName: any;
  userId: any;
  imageUrl: any;
  isLoggedIn:boolean = false;
  country:Number;
  userData: any;

myForm: FormGroup;
userInfo: {number: string, zip: number } = {number: '', zip:256};

//User:Observable<firebase.User>;

  constructor(
    private afAuth:AngularFireAuth,private diagnostic: Diagnostic,
    public storage: Storage,private menu: MenuController,private platform:Platform,private iab: InAppBrowser ,
     private authservice : AuthServiceProvider ,public formBuilder: FormBuilder,public toastCtrl: ToastController, private locationAccuracy: LocationAccuracy , private googlePlus: GooglePlus ,private facebook: Facebook ,public navCtrl: NavController, public navParams: NavParams ,  public geolocation: Geolocation ,public alertCtrl: AlertController) {
    this.locat();
    this.check('0');
   // this.User = this.afAuth.authState;
 this.handleLocationAuthorizationStatus(status);
    afAuth.authState.subscribe(user => {
      if (!user) {
        this.displayName = null;        
        return;
      }
      this.displayName = user.displayName; 
      this.email = user.email; 
      this.presentToast(this.displayName);
      console.log(this.displayName , this.email);    
    });
   
  }


  ngOnInit(): any {
    this.myForm = this.formBuilder.group({
      'number': new FormControl(),
      'zip': new FormControl(),
    })
  }

num :String;
yop :String;  
t:number=0;
mess:string;


  signInWithFacebook() {

  if (this.platform.is('cordova')) {
      return this.facebook.login(['email', 'public_profile']).then(res => {
        const facebookCredential = firebase.auth.FacebookAuthProvider.credential(res.authResponse.accessToken);
      firebase.auth().signInWithCredential(facebookCredential)
        .then( res => { 
          
this.fbc(res.email ,res.displayName ,res.photoURL);
this.presentToast(res.email +res.displayName + res.photoURL);
this.authservice.tom(res.photoURL);
this.navCtrl.push(AddtelPage);
          console.log("Firebase success: " + JSON.stringify(res)); 
        }); 
      })
    }
    else {
 this.afAuth.auth
      .signInWithPopup(new firebase.auth.FacebookAuthProvider()).then(res => {
      console.log(res.user.email+ res.user.displayName +res.user.photoURL) ; 
this.fbc(res.user.email ,res.user.displayName , res.user.photoURL);
this.presentToast(res.user.email +res.user.displayName + res.user.photoURL);
this.authservice.tom(JSON.stringify(res.user.photoURL));
this.navCtrl.push(AddtelPage);
      });
    }


  }

  signOut() {
    this.afAuth.auth.signOut();
  }

  onSubmit() {
this.num = this.myForm.value.zip + this.myForm.value.number ;
console.log('tom '+this.num);
if(this.myForm.value.number === null || this.myForm.value.number.length !== 9){
this.mess = 'incorrect telephone number (eg 779815657)';
console.log(this.mess);
}else{
this.yop = this.check(this.num);
this.mess = '';
 this.authservice.tom(this.num);
     this.authservice.verif(this.num).subscribe(
      (response) => console.log(this.tommm = response),
      (error) =>console.log(error)
    );
 this.navCtrl.push(VerifPage);
}}



facebookLogin() {
  this.presentToast('fl');
  return this.facebook.login(['email', 'public_profile'])
    .then( response => {
      const facebookCredential = firebase.auth.FacebookAuthProvider
        .credential(response.authResponse.accessToken);
      firebase.auth().signInWithCredential(facebookCredential)
        .then( success => { 
  
          this.presentToast('hello -'+ JSON.stringify(success));
          alert(JSON.stringify(success));
          console.log("Firebase success: " + JSON.stringify(success)); 
        });

    }).catch((error) => { console.log(error) ;  this.presentToast('err -'+error);});
}

fbb:string;
tommm:String ='0';

ionViewDidEnter() {
    this.menu.swipeEnable(false);
  }

  ionViewWillLeave() {
    this.menu.swipeEnable(true);
   }


check(numb){
    this.authservice.check(numb).subscribe(
      (response) => this.tommm = response,
      (error) =>console.log(error)
    ) ;
    console.log(this.tommm);
    return this.tommm ;
  }


to:string;
data:any=[];
ob:any=[];
bal:any[];
fbc(email,name,pic){
    this.ob = Observable.interval(20 * 60).subscribe(x => {
     this.data = this.authservice.fbloginn(email,name,pic).subscribe((response) =>this.bal = response,(error) =>console.log(error));
 if(this.bal.length < 1 || this.bal==undefined || this.bal==null){ 
    
   }else{}
  this.diact();
  });
}

diact(){
this.ob.unsubscribe();
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

r:any;

locat(){
  var t=0;
  if(t==0){
  this.locationAccuracy.canRequest().then((canRequest: boolean) => {
  if(canRequest) {
    // the accuracy option will be ignored by iOS
    this.r = this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      () =>{console.log('Request successful') ;t= 1},
      error => console.log(error)
    );
    if(this.r !==true){}else{
      //this.locat();
    }
  }else{


}
});}else{
  
}



}



indexxs:any;
ind:string;

store(ids){
    this.storage.set('index',ids);
   this.indexxs = this.storage.get('index');
  console.log('index = ',JSON.stringify(this.indexxs));
 this.storage.get('index').then((val) => {
   this.ind = val;
    return this.ind;
  });
  
}
fbl:any=[];

loginAction() : Promise <any> {

  return new Promise((resolve, reject) => {
   this.facebook.login(['email', 'public_profile']).then((response: FacebookLoginResponse) => {
    this.facebook.api('me?fields=i ,name,email,first_name,picture.width(720).height(720).as(picture_large)', []).then(profile => {
this.userData = {email: profile['email'], first_name: profile['first_name'], picture: profile['picture_large']['data']['url'], username: profile['name']}
this.fbc(this.userData.email ,this.userData.username , this.userData.picture);
this.presentToast(this.userData.email + this.userData.username + this.userData.picture);
this.authservice.tom(this.userData.picture);
this.navCtrl.push(AddtelPage);
     });}, err => {console.error("Error: ", err);this.presentToast('fb '+ err);});
    })
   }


 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 3000});toast.present();
  }

tp:any;
  goog():Promise <any> {
    this.presentToast('g');
  return new Promise((resolve, reject) => { 
      this.googlePlus.login({'webClientId': '149912902895-b7goua2kbqou88cmop2ig3f6g1g9ko64.apps.googleusercontent.com','offline': true}).then( res => {
      const googleCredential = firebase.auth.GoogleAuthProvider.credential(res.idToken);          
      this.displayName = res.displayName;this.email = res.email;this.familyName = res.familyName;this.givenName = res.givenName;
      this.userId = res.userId;this.imageUrl = res.imageUrl;this.fbc(this.email , this.familyName + ' '+ this.givenName , this.imageUrl);
      this.authservice.tom(this.email);this.navCtrl.push(AddtelPage);
     }, err => {console.error("Error: ", err) ; this.presentToast('Please allow google '+ err);});
  })
  }



  logout() {
    this.googlePlus.logout()
      .then(res => {
        console.log(res);
        this.displayName = "";
        this.email = "";
        this.familyName = "";
        this.givenName = "";
        this.userId = "";
        this.imageUrl = "";
        this.isLoggedIn = false;
      })
      .catch(err => console.error(err));
  }

tom:number;






onDeviceReady(){
    ///platform = cordova.platformId;
}

onError(error) {
    console.error("The following error occurred: " + error);
}

 handleLocationAuthorizationStatus(status) {
    switch (status) {
        case this.diagnostic.isLocationEnabled():
            if(this.platform.is("ios")){
                this.onError("Location services is already switched ON");
            }else{
                this.makeRequest();
            }
            break;
      
        case this.diagnostic.isLocationEnabled():
            if(this.platform.is("android")){
                this.onError("User denied permission to use location");
            }else{
                this.makeRequest();
            }
            break;
    
    }
}


makeRequest(){
 this.locationAccuracy.canRequest().then((canRequest: boolean) => {
  if(canRequest) {
    // the accuracy option will be ignored by iOS
    this.r = this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      () => console.log('Request successful'),
      error => console.log(error)
    );
    if(this.r !==true){}else{
      //this.locat();
    }
  }else{
this.locat();}
});
}

// Make the request












}
