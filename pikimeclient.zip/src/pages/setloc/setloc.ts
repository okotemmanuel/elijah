
import { Component, ViewChild, ElementRef , NgZone} from '@angular/core';
import { NavController ,LoadingController , ToastController} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { AuthServiceProvider } from '../../providers/service/service';
 //import { SetlocPage } from '../setloc/setloc';
import { Observable } from 'rxjs';
import { JstartPage } from '../jstart/jstart';
import { RequesttPage } from '../requestt/requestt';

declare var google;
 

//@IonicPage()
@Component({
  selector: 'page-setloc',
  templateUrl: 'setloc.html',
})
export class SetlocPage {
 
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  autocomplete: any;
  GoogleAutocomplete: any;
  GooglePlaces: any;
  geocoder: any ;
  autocompleteItems: any;
  nearbyItems: any = new Array<any>();
loading: any;
  markers: any;
locationn:String = '';


index:boolean = false;
index2 : boolean = false;
 v:boolean=true;

 constructor(
    public zone: NgZone,private authservice : AuthServiceProvider,
    public loadingCtrl: LoadingController,
    public navCtrl: NavController, public geolocation: Geolocation, public toastCtrl: ToastController
  ) {
    this.markers = [];
    this.geocoder = new google.maps.Geocoder;
    let elem = document.createElement("div")
    this.GooglePlaces = new google.maps.places.PlacesService(elem);
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
    this.autocomplete = {
      input: ''
    };
    this.autocompleteItems = [];
    this.loading = this.loadingCtrl.create();
    this.index2 = false;
}

  ionViewDidLoad(){
  this.loadMap();
}



ove(){
  this.v = false;
}


mess2:string;
data:any=[];
toms:any=[];
time:string;



ob:any;

diact(){
this.ob.unsubscribe();
}

cancel1(){
  this.index =false ;
}
cancle(){
  this.index2 = false;
   this.data = this.authservice.cdriver().subscribe(
      (response) => response,
      (error) =>console.log(error)
    );

}

sett(){
  this.navCtrl.push(RequesttPage);
}


updateSearchResults(){
    if (this.autocomplete.input == '') {
      this.autocompleteItems = [];
      return;
    }
    this.GoogleAutocomplete.getPlacePredictions({ input: this.autocomplete.input },
      (predictions, status) => {
        this.autocompleteItems = [];
        if(predictions){
          this.zone.run(() => {
            predictions.forEach((prediction) => {
              this.autocompleteItems.push(prediction);
            });
          });
        }

    });
}




setlooc(lat,long,place){
  this.authservice.pickup(lat,long,place);
}




selectSearchResult(item){
  this.autocompleteItems = [];

  this.geocoder.geocode({'placeId': item.place_id}, (results, status) => {
    if(status === 'OK' && results[0]){
      let position = {
          lat: results[0].geometry.location.lat,
          lng: results[0].geometry.location.lng
      };
      this.setlooc(results[0].geometry.location.lat().toString(), results[0].geometry.location.lng().toString(),item.description);

      let marker = new google.maps.Marker({
         animation: google.maps.Animation.DROP,
        position: results[0].geometry.location,
        map: this.map,
         draggable: true
      });


      this.map.setCenter(results[0].geometry.location);
       this.autocomplete.input = item.description;
     
    }
  });
  this.sett();
}




 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 3000
    });
    toast.present();
  }





 loadMap(){
    this.geolocation.getCurrentPosition().then((position) => {
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      let mapOptions = {
        center: latLng,
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
     this.addYourLocationButton(this.map,this.map); 
       console.log('loaded');       
      this.move();
  
  ;}, (err) => {
      console.log(err);
      console.log('connection error');
      this.mess = 'Internet connection lost';
    });
  }
mess:string;


LastLat:number;
LastLng: number;
setloc(){
  this.locationn = '';
}


move(){ 
google.maps.event.addListener(this.map, 'dragend', () => {
    console.log('ceter',JSON.stringify(this.map.getCenter().lat()) ,JSON.stringify(this.map.getCenter().lng()) );
        this.autocomplete.input = 'loading...' ;
this.geocoder = new google.maps.Geocoder;
  var latlng = this.map.getCenter(); 
  this.geocoder.geocode({'location':latlng}, (results, status) => {
    this.locationn = results[0].formatted_address.toString(); 
    this.setlooc(JSON.stringify(this.map.getCenter().lat()),JSON.stringify(this.map.getCenter().lng()),this.locationn);
        this.autocomplete.input =  this.locationn ;
       console.log('///////////////////s'+this.locationn);   });

});
  
}


cash:any=[];
obw:any;

ld:string="Loading...";
diactw(){
this.obw.unsubscribe();
}


set2(){
  this.index2 = true ;
}


okay(){
  this.navCtrl.push(RequesttPage);
}




diactt(){
this.obb.unsubscribe();
}


tim:any=[];
obb:any;
dat:any=[];



addYourLocationButton(map, marker) 
{
    var controlDiv = document.createElement('div');

    var firstChild = document.createElement('button');
    firstChild.style.backgroundColor = '#fff';
    firstChild.style.border = 'none';
    firstChild.style.outline = 'none';
    firstChild.style.width = '28px';
    firstChild.style.height = '28px';
    firstChild.style.borderRadius = '2px';
    firstChild.style.boxShadow = '0 1px 4px rgba(0,0,0,0.3)';
    firstChild.style.cursor = 'pointer';
    firstChild.style.marginRight = '10px';
    firstChild.style.padding = '0';
    firstChild.title = 'Your Location';
    controlDiv.appendChild(firstChild);

    var secondChild = document.createElement('div');
    secondChild.style.margin = '5px';
    secondChild.style.width = '18px';
    secondChild.style.height = '18px';
    secondChild.style.backgroundImage = 'url(https://maps.gstatic.com/tactile/mylocation/mylocation-sprite-2x.png)';
    secondChild.style.backgroundSize = '180px 18px';
    secondChild.style.backgroundPosition = '0 0';
    secondChild.style.backgroundRepeat = 'no-repeat';
    firstChild.appendChild(secondChild);

    google.maps.event.addListener(map, 'center_changed', function () {
        secondChild.style['background-position'] = '0 0';
    });

    firstChild.addEventListener('click', function () {
        var imgX = '0',
            animationInterval = setInterval(function () {
                imgX = imgX === '-18' ? '0' : '-18';
                secondChild.style['background-position'] = imgX+'px 0';
            }, 500);

        if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                map.setCenter(latlng);
                clearInterval(animationInterval);
                secondChild.style['background-position'] = '-144px 0';
            });
        } else {
            clearInterval(animationInterval);
            secondChild.style['background-position'] = '0 0';
        }
    });

    //controlDiv.index = 1;
    map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(controlDiv);
}




}