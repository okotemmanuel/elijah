import { Component, ViewChild, ElementRef , NgZone} from '@angular/core';
import { NavController ,LoadingController , ToastController , AlertController} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { AuthServiceProvider } from '../../providers/service/service';
 //import { SetlocPage } from '../setloc/setloc';
import { Observable } from 'rxjs';
import { JstartPage } from '../jstart/jstart';
import { RequesttPage } from '../requestt/requestt';

declare var google;

@Component({
  selector: 'page-track',
  templateUrl: 'track.html',
})
export class TrackPage {
 
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  autocomplete: any;
  GoogleAutocomplete: any;
  GooglePlaces: any;
  geocoder: any ;
  autocompleteItems: any;
  fit:any;
  nearbyItems: any = new Array<any>();
loading: any;
  markers: any;
locationn:String = '';
 directionsService = new google.maps.DirectionsService;
  directionsDisplay = new google.maps.DirectionsRenderer;



index:boolean = true;
index2 : boolean = false;
index3 : boolean = false;

index4 : boolean=true;
 v:boolean=true;

 constructor(
    public zone: NgZone,private authservice : AuthServiceProvider,
    public loadingCtrl: LoadingController,public alertCtrl: AlertController,
    public navCtrl: NavController, public geolocation: Geolocation, public toastCtrl: ToastController
  ) {
    this.markers = [];
    this.geocoder = new google.maps.Geocoder;
    let elem = document.createElement("div")
    this.GooglePlaces = new google.maps.places.PlacesService(elem);
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
    //this.fit = new google.maps.Map.fitBounds();
    this.autocomplete = {
      input: ''
    };
    this.autocompleteItems = [];
    //loading = this.loadingCtrl.create();
   //this.checkrequest();
    this.presentLoading();
    this.index2 = false;
    //this.anima();
    this.getp();
     if( this.authservice.hnumb==undefined){
    this.con = "Searching for Nearest driver ...";
  }else{
  this.con = "Connecting driver ...";
}
}


 ionViewDidLoad(){
    this.initMap();
  }


  initMap() {
    this.map = new google.maps.Map(this.mapElement.nativeElement, {
     zoom: 13,
      center: {lat: 0.3476, lng: 32.5825}
    });

    this.directionsDisplay.setMap(this.map);
     // this.calculateAndDisplayRoute();
  }

pplac:string='loading';
dplac:string='loading';

plat:number;
plong:number;
dlat:number;
dlong:number;

obr:any;
getp(){
  var t=1;
    this.obr = Observable.interval(20 * 60).subscribe(x => {
  this.pplac = this.authservice.place();
  this.dplac = this.authservice.dlace();

this.plat = parseInt(this.authservice.plat);
this.plong = parseInt(this.authservice.plong);

  if(t==2){
 this.obr.unsubscribe();
 this.calculateAndDisplayRoute();
  }else{
t++;
  console.log('--------------'+this.pplac , this.dplac);
  }
    });
}


  calculateAndDisplayRoute() {
    this.directionsService.route({
      origin: this.pplac,
      destination: this.dplac,
      travelMode: 'DRIVING'
    }, (response, status) => {
      if (status === 'OK') {
        this.directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }






obt:any;


ove(){
  this.v = false;
}


mess2:string;
data:any=[];
toms:any=[];
time:string;

 presentLoading() {
    this.index = false;
    this.funn();
    this.authservice.send();
  }

olb:any;
loader:any;
con:string;

 canlc(){
 this.showRadio();
 }

funn(){
  if(this.authservice.hnumb==undefined){
    this.con = "Searching for Nearest driver ...";
  }else{
  this.con = "Connecting driver ...";
}
var t=0;
var k=0;
 this.olb = Observable.interval(20 * 60).subscribe(x => {
   this.data = this.authservice.getdriver().subscribe(
      (response) => console.log(this.toms = response),
      (error) =>console.log(error)
    );
      if(k==20){
        this.presentToast('Rider Not found Around , Please Try again');
          this.navCtrl.pop();
             this.olb.unsubscribe();
      }else{
        k++;
      }
   console.log('received', this.data);
   if(this.toms.length > 2){ 
  
     if(t===1){
        this.index2 = false;
          this.index4 = false;
        this.index3 = true;
    this.authservice.setdrtell(this.toms[3]);
    this.authservice.setidr(this.toms[0]);

      this.time = this.data[2] , 'mins';
      //loader.dismiss();

       this.anima();

    console.log(this.toms[6] +'----'+this.toms[7]);
    this.dlat=parseInt(this.toms[6]);
    this.dlong=parseInt(this.toms[7]);
console.log('url -----------'+this.toms[8]);
this.authservice.driverd(this.toms[2],this.toms[8], this.toms[4]);
  this.authservice.direction(this.dlat , this.dlong).subscribe(
      (response) => console.log(this.dire = response),
      (error) =>console.log(error)
    );

      this.olb.unsubscribe();
      console.log('dismiss');
     
     }else{
       t=1;
     }
      }else{
   }
  });


}
diact(){
this.olb.unsubscribe();
}

ras(){
  this.index3 = false;
   this.index2 = true;
}
das(){
   this.index3 = true;
    this.index2 = false;
}
cancel1(){
  this.index =false ;
}
cancle(){
  this.index2 = false;
  this.index3 = false;
   this.data = this.authservice.cdriver().subscribe(
      (response) => response,
      (error) =>console.log(error)
    );
      this.olb.unsubscribe();
this.navCtrl.pop();
}

sett(){
  this.navCtrl.push(RequesttPage);
}






 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 10000
    });
    toast.present();
  }





cash:any=[];
obw:any;
dire:any;
set(){
 this.obw = Observable.interval(20 * 60).subscribe(x => {
 this.data = this.authservice.getdist().subscribe(
      (response) => console.log(this.cash = response),
      (error) =>console.log(error)
    );


    if(this.cash.length >  1){
    this.authservice.setcash(this.cash[1]);
  this.olb.unsubscribe();
 
   this.index = true;
    }else{
     
    }
  });
}
ld:string="Loading...";
diactw(){
this.obw.unsubscribe();
}



set2(){
  this.index2 = true ;
}




 

diactt(){
this.obb.unsubscribe();
}

 animateCircle(line) {  
          var count = 0;    var a= 0;
          window.setInterval(function() {
   if(a==0){
            count = (count + 1) % 200;
            var icons = line.get('icons');
            icons[0].offset = (count / 2) + '%';
           if(icons[0].offset ==='90%'){a= 1;}
            line.set('icons', icons);}  else{
      } }, 100);
      }

tim:any=[];
obb:any;
dat:any=[];

x:number=0;
anima(){
  ///this.index3 = false;
var bounds = new google.maps.LatLngBounds();
 bounds.extend({lat:0.3063435,lng:32.653706},{lat:0.3062847,lng:32.6539955} );
//this.map.fit(bounds);

 this.obb = Observable.interval(20 * 60).subscribe(x => {
   this.dat= this.authservice.cstart(this.toms[0]).subscribe(
      (response) => console.log(this.tim = response),
      (error) =>console.log(error)
    );
 //console.log(this.tim);
 this.dire = this.dire;
 console.log(x);


 if(this.tim===1){
console.log('great = ', this.tim);
  if(this.x===2){
this.navCtrl.push(JstartPage);
this.obb.unsubscribe();
this.diactt();
        
 }else{
   this.x++;
 }

 }else{
   console.log('try = ', this.tim);
 }
  });



    this.geolocation.getCurrentPosition().then((position) => {
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      let mapOptions = {
        center: latLng,
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
     // this.addMarker(this.map);
   var lineSymbol = {
           path:'M432,251c-38.984,0-71.526,28.036-78.569,65h-30.404c7.339-53.583,53.406-95,108.973-95c20.238,0,40.014,5.538,57.19,16.014l15.622-25.611C482.93,198.055,457.751,191,432,191H304.43c-6.191-17.461-22.874-30-42.43-30H159.26l11.163-30H220v-30h-70.423l-22.326,60h-5.629c-25.381,0-47.827,16.178-55.853,40.257L59.189,221H80c8.222,0,16.234,0.914,23.946,2.633l-10.605,28.501C88.999,251.401,84.547,251,80,251c-44.112,0-80,35.888-80,80s35.888,80,80,80s80-35.888,80-80c0-28.947-15.454-54.352-38.545-68.399l10.598-28.482C166.523,252.713,190,289.165,190,331v15h163.431c7.043,36.964,39.585,65,78.569,65c44.112,0,80-35.888,80-80S476.112,251,432,251z M130,331c0,27.57-22.43,50-50,50s-50-22.43-50-50s22.43-50,50-50c0.864,0,1.722,0.022,2.576,0.066l-19.634,52.766l28.117,10.462l19.621-52.732C122.425,300.719,130,314.987,130,331z M432,381c-22.346,0-41.312-14.736-47.698-35H447v-30h-62.698c6.387-20.264,25.352-35,47.698-35c27.57,0,50,22.43,50,50S459.57,381,432,381z',
          scale: 0.15,
          strokeColor: '#393',
          //scale: 0.4,
fillColor: "#427af4", //<-- Car Color, you can change it 
fillOpacity: 1,
strokeWeight: 1,

anchor: new google.maps.Point(160, 160),
origin: new google.maps.Point(30, 30),
rotation: 140,
        };
console.log(this.dire);
  var line = new google.maps.Polyline({
          path:this.dire,
          icons: [{
            icon:lineSymbol,
            offset: '100%'
          }],
          map: this.map
        });
 this.animateCircle(line);
    }, (err) => {
      console.log(err);
      console.log('connection error');
    });
  }
 
  showRadio() {
    let alert = this.alertCtrl.create();
    alert.setTitle('Reason for your cancellation');

    alert.addInput({
      type: 'radio',
      label: 'My Boda is too far',
      value: 'blue',
      checked: true
    });

      alert.addInput({
      type: 'radio',
      label: 'My Boda has Not called',
      value: 'blue'
    });

     alert.addInput({
      type: 'radio',
      label: 'Am choosing an alternative ',
      value: 'blue'
    });

    alert.addInput({
      type: 'radio',
      label: 'Other ',
      value: 'blue'
    });

    alert.addButton('Cancel');
    alert.addButton({
      text: 'OK',
      handler: data => {
           this.presentToast('Request Canceled');
       this.olb.unsubscribe();
          this.navCtrl.pop();
       ;
      }
    });
    alert.present();
  }



}