import { Component, ViewChild, ElementRef , NgZone} from '@angular/core';
import { NavController ,LoadingController , ToastController} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { AuthServiceProvider } from '../../providers/service/service';
 //import { SetlocPage } from '../setloc/setloc';
import { Observable } from 'rxjs';
import { JstartPage } from '../jstart/jstart';
import { RequesttPage } from '../requestt/requestt';

declare var google;

@Component({
  selector: 'page-track',
  templateUrl: 'track.html',
})
export class TrackPage {
 
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  autocomplete: any;
  GoogleAutocomplete: any;
  GooglePlaces: any;
  geocoder: any ;
  autocompleteItems: any;
  fit:any;
  nearbyItems: any = new Array<any>();
loading: any;
  markers: any;
locationn:String = '';
 directionsService = new google.maps.DirectionsService;
  directionsDisplay = new google.maps.DirectionsRenderer;



index:boolean = true;
index2 : boolean = false;
index3 : boolean = false;
 v:boolean=true;

 constructor(
    public zone: NgZone,private authservice : AuthServiceProvider,
    public loadingCtrl: LoadingController,
    public navCtrl: NavController, public geolocation: Geolocation, public toastCtrl: ToastController
  ) {
    this.markers = [];
    this.geocoder = new google.maps.Geocoder;
    let elem = document.createElement("div")
    this.GooglePlaces = new google.maps.places.PlacesService(elem);
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
    //this.fit = new google.maps.Map.fitBounds();
    this.autocomplete = {
      input: ''
    };
    this.autocompleteItems = [];
    this.loading = this.loadingCtrl.create();
   //this.checkrequest();
    this.presentLoading();
    this.index2 = false;
    //this.anima();
    this.getp();
}


 ionViewDidLoad(){
    this.initMap();
  }


  initMap() {
    this.map = new google.maps.Map(this.mapElement.nativeElement, {
     zoom: 13,
      center: {lat: 0.3476, lng: 32.5825}
    });

    this.directionsDisplay.setMap(this.map);
     // this.calculateAndDisplayRoute();
  }

pplac:string='loading';
dplac:string='loading';

plat:number;
plong:number;
dlat:number;
dlong:number;

obr:any;
getp(){
  var t=1;
    this.obr = Observable.interval(20 * 60).subscribe(x => {
  this.pplac = this.authservice.place();
  this.dplac = this.authservice.dlace();

this.plat = parseInt(this.authservice.plat);
this.plong = parseInt(this.authservice.plong);

  if(t==2){
 this.obr.unsubscribe();
 this.calculateAndDisplayRoute();
  }else{
t++;
  console.log('--------------'+this.pplac , this.dplac);
  }
    });
}


  calculateAndDisplayRoute() {
    this.directionsService.route({
      origin: this.pplac,
      destination: this.dplac,
      travelMode: 'DRIVING'
    }, (response, status) => {
      if (status === 'OK') {
        this.directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }






obt:any;
/*
checkrequest(){
  var t=0;
  
   this.obt = Observable.interval(20 * 60).subscribe(x => {
   this.data = this.authservice.getdriver().subscribe(
      (response) => console.log(this.toms = response),
      (error) =>console.log(error)
    );
   console.log('received', this.data);
  if(t===5){
    this.obt.unsubscribe();
  } else{
    t++;

if(t==1 || t===0||this.toms.length === 1 || this.toms ===undefined || this.toms ===null || this.toms ===0 ){ 
   this.index2 = false;
  }else{
    this.authservice.setdrtell(this.toms[3]);
    console.log(this.toms[6] +'----'+this.toms[7]);
    this.dlat=parseInt(this.toms[6]);
    this.dlong=parseInt(this.toms[7]);

      this.authservice.direction(this.dlat , this.dlong).subscribe(
      (response) => console.log(this.dire = response),
      (error) =>console.log(error)
    );
      this.index3 = true;
        this.time = this.data[2] , 'mins';
        //this.mess2 = 'YOU HAVE APENDING REQUEST';
   }
  }

  });
}*/

ove(){
  this.v = false;
}


mess2:string;
data:any=[];
toms:any=[];
time:string;

 presentLoading() {
    this.index = false;
    this.funn();
    this.authservice.send();
  }

olb:any;
funn(){
   const loader = this.loadingCtrl.create({
      content: "Searching Nearest Rider...",
      duration: 100000
    });
    loader.present();
var t=0;
var k=0;
 this.olb = Observable.interval(20 * 60).subscribe(x => {
   this.data = this.authservice.getdriver().subscribe(
      (response) => console.log(this.toms = response),
      (error) =>console.log(error)
    );
      if(k==50){
        this.presentToast('Rider Not found Around , Please Try again');
          this.navCtrl.pop(TrackPage);
           loader.dismiss();
             this.olb.unsubscribe();
      }else{
        k++;
      }
   console.log('received', this.data);
   if(this.toms.length > 2){ 
  
     if(t===1){
        this.index2 = false;
        this.index3 = true;
    this.authservice.setdrtell(this.toms[3]);
    this.authservice.setidr(this.toms[0]);

      this.time = this.data[2] , 'mins';
      loader.dismiss();
       this.anima();

    console.log(this.toms[6] +'----'+this.toms[7]);
    this.dlat=parseInt(this.toms[6]);
    this.dlong=parseInt(this.toms[7]);

  this.authservice.direction(this.dlat , this.dlong).subscribe(
      (response) => console.log(this.dire = response),
      (error) =>console.log(error)
    );

      this.olb.unsubscribe();
      console.log('dismiss');
     
     }else{
       t=1;
     }
      }else{
   }
  });


}
diact(){
this.olb.unsubscribe();
}

ras(){
  this.index3 = false;
   this.index2 = true;
}
das(){
   this.index3 = true;
    this.index2 = false;
}
cancel1(){
  this.index =false ;
}
cancle(){
  this.index2 = false;
  this.index3 = false;
   this.data = this.authservice.cdriver().subscribe(
      (response) => response,
      (error) =>console.log(error)
    );
      this.olb.unsubscribe();
this.navCtrl.pop();
}

sett(){
  this.navCtrl.push(RequesttPage);
}






 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 10000
    });
    toast.present();
  }





cash:any=[];
obw:any;
dire:any;
set(){
 this.obw = Observable.interval(20 * 60).subscribe(x => {
 this.data = this.authservice.getdist().subscribe(
      (response) => console.log(this.cash = response),
      (error) =>console.log(error)
    );


    if(this.cash.length >  1){
    this.authservice.setcash(this.cash[1]);
  this.olb.unsubscribe();
 
   this.index = true;
    }else{
     
    }
  });
}
ld:string="Loading...";
diactw(){
this.obw.unsubscribe();
}



set2(){
  this.index2 = true ;
}




 

diactt(){
this.obb.unsubscribe();
}

 animateCircle(line) {  
          var count = 0;    var a= 0;
          window.setInterval(function() {
   if(a==0){
            count = (count + 1) % 200;
            var icons = line.get('icons');
            icons[0].offset = (count / 2) + '%';
           if(icons[0].offset ==='90%'){a= 1;}
            line.set('icons', icons);}  else{
      } }, 100);
      }

tim:any=[];
obb:any;
dat:any=[];

x:number=0;
anima(){
  ///this.index3 = false;
var bounds = new google.maps.LatLngBounds();
 bounds.extend({lat:0.3063435,lng:32.653706},{lat:0.3062847,lng:32.6539955} );
//this.map.fit(bounds);

 this.obb = Observable.interval(20 * 60).subscribe(x => {
   this.dat= this.authservice.cstart().subscribe(
      (response) => console.log(this.tim = response),
      (error) =>console.log(error)
    );
 //console.log(this.tim);
 this.dire = this.dire;
 console.log(x);


 if(this.tim===1){
console.log('great = ', this.tim);
  if(this.x===2){
this.navCtrl.push(JstartPage);
this.obb.unsubscribe();
this.diactt();
        
 }else{
   this.x++;
 }

 }else{
   console.log('try = ', this.tim);
 }
  });



    this.geolocation.getCurrentPosition().then((position) => {
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      let mapOptions = {
        center: latLng,
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
     // this.addMarker(this.map);
   var lineSymbol = {
         // path:'M51.82,275.072c28.625,0,51.823-23.203,51.823-51.822c0-1.797-0.091-3.568-0.272-5.318l20.881-3.666c0,0,0.707-0.942,5.854,4.215c2.201,2.201,5.196,2.48,7.928,2.123c4.857,1.642,15.843,4.801,28.531,4.801c9.844,0,20.687-1.916,30.38-7.954c14.779-9.217,23.52-25.994,26.166-49.726c6.509-7.177,13.287-12.777,19.93-17.137l5.707,16.997c-17.922,8.155-30.406,26.181-30.406,47.151c0,28.62,23.208,51.818,51.822,51.818c28.615,0,51.823-23.203,51.823-51.818c0-28.624-23.208-51.819-51.823-51.819c-3.904,0-7.699,0.466-11.36,1.287l-6.4-19.071c19.967-10.175,36.495-10.022,36.495-10.022l6.204,3.395l20.608,1.639c-12.412-14.4-61.36-11.83-61.36-11.83l10.429-1.755c0,0-0.353-11.242-6.794-25.06c-6.441-13.817-13.468-21.898-13.468-21.898c-0.643,0.725-1.062,1.58-1.394,2.465c0.114-9.512,0.238-19.024,0.969-28.521c0.011-0.132-0.036-0.223-0.042-0.344c0.233-0.976-0.077-2.027-1.269-2.61c-3.842-1.877-7.622-3.461-11.945-3.674c-1.176-0.057-2.253,0.854-2.553,1.947c-1.367,4.94-1.729,10.116-1.14,15.19c-0.425-0.86-0.839-1.717-1.305-2.566c-0.72-1.294-1.968-1.492-3.045-1.092c-1.212-0.208-2.589,0.259-3.127,1.729c-0.87,2.374-2.761,3.971-2.859,6.721c-0.154,4.324,4.868,7.133,8.047,8.862c0.602,0.329,1.202,0.345,1.771,0.238c1.563,6.33,2.082,12.868,1.698,19.581c-9.673,6.273-5.944,11.995-5.944,11.995l-1.756,2.985c0,0-9.139-12.997-38.996,6.325c-29.857,19.322-53.394,7.026-73.066,0c-19.671-7.027-92.039-8.779-92.039-8.779c35.6,5.385,51.29,34.659,51.29,34.659l-28.102-17.328c-12.414,1.173-9.137,14.286-9.137,14.286l51.758,31.615c10.069-3.749,21.544,7.493,21.544,7.493l10.773,18.973l-14.76,4.204c-7.664-19.05-26.273-32.514-48.068-32.514C23.198,171.442,0,194.646,0,223.26S23.203,275.072,51.82,275.072z M270.158,178.816c19.807,0,35.91,16.109,35.91,35.915c0,19.802-16.104,35.91-35.91,35.91c-19.806,0-35.91-16.108-35.91-35.91c0-13.924,7.975-25.999,19.594-31.954l11.288,33.637c0.746,2.217,2.812,3.62,5.028,3.62c0.554,0,1.124-0.094,1.683-0.274c2.775-0.938,4.272-3.94,3.346-6.722l-11.289-33.642C265.933,179.039,268.02,178.816,270.158,178.816z M233.378,73.317c1.615-1.261,3.175-2.493,4.66-3.791c-0.207,7.842-0.248,15.69-0.414,23.537c-1.408,0.518-2.682,1.043-3.853,1.569c0.14-7.083-0.725-14.004-2.708-20.674C231.814,74.07,232.633,73.89,233.378,73.317z M176.947,156.183c24.699-7.407,33.077,3.744,35.708,9.704c-2.18,20.682-9.289,35.035-21.282,42.538c-15.731,9.833-36.34,5.991-46.235,3.241C146.225,197.142,151.491,163.82,176.947,156.183z M51.82,187.34c14.483,0,26.952,8.632,32.632,21.002L45.56,219.418l1.406,8.43l40.635-7.141c0.06,0.844,0.129,1.684,0.129,2.543c0,19.806-16.109,35.915-35.916,35.915c-19.804,0-35.913-16.109-35.913-35.915C15.907,203.448,32.021,187.34,51.82,187.34z',
         // path1:'z43.781,28.15,43.781,120.23,844.302,709.51C519.53-319.53-901.61-319.53-0,408.91-c519.53,619.53-519.53,901.61-608.91,0c345.2,921.0,486.1,921.0,448.0,60.0c141.7-536.04l34.8,604.1l814.912,65.54L200.12,236.23,236.8,259.62,0,384.41c43.781,28.15M z381.651,749.671,28.361,194.151,241.791,522.641C142.3,532.64-199.5,43.63-338.9,137.51-c835.24,282.12-530.53,982.9-286.02,81.2-c407.9,807.53,447.3,770.33,704.7-996.42c381.651,749.671M z713.37,873.332,98.37,336.232,70.47,418.132C476.02-807.2-400.41-527.0-380.7-41.0c965.1,358.3-340.1,286.2-815.0,804.1-c735.32,414.0-96.51,842.0-248.7,702.0-c197.3-66.4,394.2-571.3,162.1-516.1c713.37,873.332M z618.871,851.072,618.871,20.862,930.971,339.562C246.33-982.11-l227.6-643.3,49.3-272.4,839.0-577.2c472.0-386.1,490.0-421.1,0,455.0c26.3,820.5,26.3,218.2,712.2,647.0c736.33,882.11l459.13-495.91,999.52-579.7,429.31-0c19.53-19.53-801.61-19.53-0,608.91-c19.53,19.53-19.53,401.61-208.91,0c519.53,19.53,901.61,19.53,0,708.91c618.871,851.072M z270.572,28.15,270.572,302.32S62.322,0,646.491,0,244.171,891.32C415.23-860.84-415.23-372.62-50.91-466.7-c402.4,67.41-l379.81,377.01l394.7,445.12,394.7,445.12,947.3-960.01c516.13,857.15l682.41,731.9-682.41,731.9-371.1,414.21-c823.71-201.82-l956.43,92.15,956.43,92.15,583.5,6.53c977.8-930.29-977.8-930.29-720.7-176.91-c0,660.37-620.7,493.35-223.91,758.92-c523.6,699.83-799.21-931.9-0,0c589.2,657.1-l599.11,449.5-599.11,449.5-372.6,376.9-c185.91,896.1,868.21,280.2,33.6,365.1c832.0,177.1,543.0,202.1,923.0,206.0c268.8,740.8,331.7,868.4,423.4,451.0-c127.6,958.2-179.3,167.2-473.2,78.0-c927.1,721.3-952.0,985.2-802.0-212.1-c290.1-540.3-294.1-869.1-492.1-27.0-c665.2-503.1-717.1-938.0-68.0-524.0-c91.51,41.1-611.01,927.1-49.4,763.1-c749.1,355.2-458.0,352.2-750.0-671.1-c476.3-549.11-164.3-226.7-778.1-248.3-c16.2-962.1-720.2-770.0-679.0-332.0c443.0-240.0-322.0-630.0-231.0-110.0c125.82-969.0,420.91-832.0,215.9-411.0c564.2,493.1-85.1,260.1-527.0,346.0-c898.12-864.31-898.12-864.31-718.31-144.6-c60.52-497.6-242.11-353.0-0,0c557.1-924.01l38.11-63.16-38.11-63.16-4.41-214.21-c936.1,806.02l593.3,402.6l220.01-594.63,220.01-594.63,571.01-769.91c170.91-4.6-l782.1,63.11-664.0,996.7-0,409.3-c918.15-328.15-918.15-802.32-426.82-0c818.15-328.15,302.32-328.15,0,516.82c818.15,228.15,818.15,802.32,26.82,0c151.74,604.03-181.62,604.03-551.8,229.71-c799.61,707.5l731.71-39.91,777.21-782.31,771.7-905.6c627.94-661.62,499.52-25.32,712.9-977.41c459.7-83.03,619.1-786.02,0,448.9c108.4,135.82,108.4,348.51,246.1,758.4c321.2,829.7,84.2,691.5,102.2,102.2c512.4,458.5,249.0-707.0,0,0c666.3-188.02l813.5-272.0-865.3-190.0-797.1-0c228.15-328.15,302.32-328.15,0,526.82c270.572,28.15M',
          //path:'M51.82,275.072c28.625,0,51.823-23.203,51.823-51.822c0-1.797-0.091-3.568-0.272-5.318l20.881-3.666c0,0,0.707-0.942,5.854,4.215c2.201,2.201,5.196,2.48,7.928,2.123c4.857,1.642,15.843,4.801,28.531,4.801c9.844,0,20.687-1.916,30.38-7.954c14.779-9.217,23.52-25.994,26.166-49.726c6.509-7.177,13.287-12.777,19.93-17.137l5.707,16.997    c-17.922,8.155-30.406,26.181-30.406,47.151c0,28.62,23.208,51.818,51.822,51.818c28.615,0,51.823-23.203,51.823-51.818 c0-28.624-23.208-51.819-51.823-51.819c-3.904,0-7.699,0.466-11.36,1.287l-6.4-19.071c19.967-10.175,36.495-10.022,36.495-10.022    l6.204,3.395l20.608,1.639c-12.412-14.4-61.36-11.83-61.36-11.83l10.429-1.755c0,0-0.353-11.242-6.794-25.06    c-6.441-13.817-13.468-21.898-13.468-21.898c-0.643,0.725-1.062,1.58-1.394,2.465c0.114-9.512,0.238-19.024,0.969-28.521    c0.011-0.132-0.036-0.223-0.042-0.344c0.233-0.976-0.077-2.027-1.269-2.61c-3.842-1.877-7.622-3.461-11.945-3.674    c-1.176-0.057-2.253,0.854-2.553,1.947c-1.367,4.94-1.729,10.116-1.14,15.19c-0.425-0.86-0.839-1.717-1.305-2.566    c-0.72-1.294-1.968-1.492-3.045-1.092c-1.212-0.208-2.589,0.259-3.127,1.729c-0.87,2.374-2.761,3.971-2.859,6.721    c-0.154,4.324,4.868,7.133,8.047,8.862c0.602,0.329,1.202,0.345,1.771,0.238c1.563,6.33,2.082,12.868,1.698,19.581    c-9.673,6.273-5.944,11.995-5.944,11.995l-1.756,2.985c0,0-9.139-12.997-38.996,6.325c-29.857,19.322-53.394,7.026-73.066,0    c-19.671-7.027-92.039-8.779-92.039-8.779c35.6,5.385,51.29,34.659,51.29,34.659l-28.102-17.328    c-12.414,1.173-9.137,14.286-9.137,14.286l51.758,31.615c10.069-3.749,21.544,7.493,21.544,7.493l10.773,18.973l-14.76,4.204    c-7.664-19.05-26.273-32.514-48.068-32.514C23.198,171.442,0,194.646,0,223.26S23.203,275.072,51.82,275.072z M270.158,178.816    c19.807,0,35.91,16.109,35.91,35.915c0,19.802-16.104,35.91-35.91,35.91c-19.806,0-35.91-16.108-35.91-35.91    c0-13.924,7.975-25.999,19.594-31.954l11.288,33.637c0.746,2.217,2.812,3.62,5.028,3.62c0.554,0,1.124-0.094,1.683-0.274    c2.775-0.938,4.272-3.94,3.346-6.722l-11.289-33.642C265.933,179.039,268.02,178.816,270.158,178.816z M233.378,73.317    c1.615-1.261,3.175-2.493,4.66-3.791c-0.207,7.842-0.248,15.69-0.414,23.537c-1.408,0.518-2.682,1.043-3.853,1.569    c0.14-7.083-0.725-14.004-2.708-20.674C231.814,74.07,232.633,73.89,233.378,73.317z M176.947,156.183    c24.699-7.407,33.077,3.744,35.708,9.704c-2.18,20.682-9.289,35.035-21.282,42.538c-15.731,9.833-36.34,5.991-46.235,3.241    C146.225,197.142,151.491,163.82,176.947,156.183z M51.82,187.34c14.483,0,26.952,8.632,32.632,21.002L45.56,219.418l1.406,8.43    l40.635-7.141c0.06,0.844,0.129,1.684,0.129,2.543c0,19.806-16.109,35.915-35.916,35.915c-19.804,0-35.913-16.109-35.913-35.915C15.907,203.448,32.021,187.34,51.82,187.34z',
         // path:'M51.82,275.072c28.625,0,51.823-23.203,51.823-51.822c0-1.797-0.091-3.568-0.272-5.318l20.881-3.666    c0,0,0.707-0.942,5.854,4.215c2.201,2.201,5.196,2.48,7.928,2.123c4.857,1.642,15.843,4.801,28.531,4.801    c9.844,0,20.687-1.916,30.38-7.954c14.779-9.217,23.52-25.994,26.166-49.726c6.509-7.177,13.287-12.777,19.93-17.137l5.707,16.997    c-17.922,8.155-30.406,26.181-30.406,47.151c0,28.62,23.208,51.818,51.822,51.818c28.615,0,51.823-23.203,51.823-51.818    c0-28.624-23.208-51.819-51.823-51.819c-3.904,0-7.699,0.466-11.36,1.287l-6.4-19.071c19.967-10.175,36.495-10.022,36.495-10.022    l6.204,3.395l20.608,1.639c-12.412-14.4-61.36-11.83-61.36-11.83l10.429-1.755c0,0-0.353-11.242-6.794-25.06    c-6.441-13.817-13.468-21.898-13.468-21.898c-0.643,0.725-1.062,1.58-1.394,2.465c0.114-9.512,0.238-19.024,0.969-28.521    c0.011-0.132-0.036-0.223-0.042-0.344c0.233-0.976-0.077-2.027-1.269-2.61c-3.842-1.877-7.622-3.461-11.945-3.674    c-1.176-0.057-2.253,0.854-2.553,1.947c-1.367,4.94-1.729,10.116-1.14,15.19c-0.425-0.86-0.839-1.717-1.305-2.566    c-0.72-1.294-1.968-1.492-3.045-1.092c-1.212-0.208-2.589,0.259-3.127,1.729c-0.87,2.374-2.761,3.971-2.859,6.721    c-0.154,4.324,4.868,7.133,8.047,8.862c0.602,0.329,1.202,0.345,1.771,0.238c1.563,6.33,2.082,12.868,1.698,19.581    c-9.673,6.273-5.944,11.995-5.944,11.995l-1.756,2.985c0,0-9.139-12.997-38.996,6.325c-29.857,19.322-53.394,7.026-73.066,0    c-19.671-7.027-92.039-8.779-92.039-8.779c35.6,5.385,51.29,34.659,51.29,34.659l-28.102-17.328    c-12.414,1.173-9.137,14.286-9.137,14.286l51.758,31.615c10.069-3.749,21.544,7.493,21.544,7.493l10.773,18.973l-14.76,4.204    c-7.664-19.05-26.273-32.514-48.068-32.514C23.198,171.442,0,194.646,0,223.26S23.203,275.072,51.82,275.072z M270.158,178.816    c19.807,0,35.91,16.109,35.91,35.915c0,19.802-16.104,35.91-35.91,35.91c-19.806,0-35.91-16.108-35.91-35.91    c0-13.924,7.975-25.999,19.594-31.954l11.288,33.637c0.746,2.217,2.812,3.62,5.028,3.62c0.554,0,1.124-0.094,1.683-0.274    c2.775-0.938,4.272-3.94,3.346-6.722l-11.289-33.642C265.933,179.039,268.02,178.816,270.158,178.816z M233.378,73.317    c1.615-1.261,3.175-2.493,4.66-3.791c-0.207,7.842-0.248,15.69-0.414,23.537c-1.408,0.518-2.682,1.043-3.853,1.569    c0.14-7.083-0.725-14.004-2.708-20.674C231.814,74.07,232.633,73.89,233.378,73.317z M176.947,156.183    c24.699-7.407,33.077,3.744,35.708,9.704c-2.18,20.682-9.289,35.035-21.282,42.538c-15.731,9.833-36.34,5.991-46.235,3.241    C146.225,197.142,151.491,163.82,176.947,156.183z M51.82,187.34c14.483,0,26.952,8.632,32.632,21.002L45.56,219.418l1.406,8.43    l40.635-7.141c0.06,0.844,0.129,1.684,0.129,2.543c0,19.806-16.109,35.915-35.916,35.915c-19.804,0-35.913-16.109-35.913-35.915    C15.907,203.448,32.021,187.34,51.82,187.34z',
           path:'M432,251c-38.984,0-71.526,28.036-78.569,65h-30.404c7.339-53.583,53.406-95,108.973-95c20.238,0,40.014,5.538,57.19,16.014l15.622-25.611C482.93,198.055,457.751,191,432,191H304.43c-6.191-17.461-22.874-30-42.43-30H159.26l11.163-30H220v-30h-70.423l-22.326,60h-5.629c-25.381,0-47.827,16.178-55.853,40.257L59.189,221H80c8.222,0,16.234,0.914,23.946,2.633l-10.605,28.501C88.999,251.401,84.547,251,80,251c-44.112,0-80,35.888-80,80s35.888,80,80,80s80-35.888,80-80c0-28.947-15.454-54.352-38.545-68.399l10.598-28.482C166.523,252.713,190,289.165,190,331v15h163.431c7.043,36.964,39.585,65,78.569,65c44.112,0,80-35.888,80-80S476.112,251,432,251z M130,331c0,27.57-22.43,50-50,50s-50-22.43-50-50s22.43-50,50-50c0.864,0,1.722,0.022,2.576,0.066l-19.634,52.766l28.117,10.462l19.621-52.732C122.425,300.719,130,314.987,130,331z M432,381c-22.346,0-41.312-14.736-47.698-35H447v-30h-62.698c6.387-20.264,25.352-35,47.698-35c27.57,0,50,22.43,50,50S459.57,381,432,381z',
          scale: 0.15,
          strokeColor: '#393',
          //scale: 0.4,
fillColor: "#427af4", //<-- Car Color, you can change it 
fillOpacity: 1,
strokeWeight: 1,

anchor: new google.maps.Point(160, 160),
origin: new google.maps.Point(30, 30),
rotation: 140,
        };
console.log(this.dire);
  var line = new google.maps.Polyline({
          path:this.dire,
          icons: [{
            icon:lineSymbol,
            offset: '100%'
          }],
          map: this.map
        });
 this.animateCircle(line);
    }, (err) => {
      console.log(err);
      console.log('connection error');
    });
  }
 

}