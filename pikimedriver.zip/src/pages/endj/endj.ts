import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,LoadingController, Platform} from 'ionic-angular';
import {Observable} from 'rxjs'
/**
 * Generated class for the EndjPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import { Geolocation } from '@ionic-native/geolocation';
import { LocationAccuracy } from '@ionic-native/location-accuracy';

import { AuthServiceProvider } from '../../providers/service/service';
import { HomePage } from '../home/home';
declare var google: any;

@IonicPage()
@Component({
  selector: 'page-endj',
  templateUrl: 'endj.html',
})
export class EndjPage {
 geocoder: any;
  constructor(public geolocation: Geolocation , private platform:Platform,private locationAccuracy: LocationAccuracy, public loadingCtrl: LoadingController,private authservice : AuthServiceProvider,public navCtrl: NavController, public navParams: NavParams) {
      this.getdata();
      this.geocoder = new google.maps.Geocoder;

this.timee();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EndjPage');
  }

getdata(){
 this.data = this.authservice.getdata();
 console.log(this.data[0][3] , this.data[0]);
}


data:any=[];

ob:any=[];
pol:any;
  set(){
      this.loc();
     this.authservice.endj(this.data[0]).subscribe(
      (response) => response,
      (error) =>console.log(error)
 );
 const loader = this.loadingCtrl.create({
      content: "Please Wait...",
      duration: 100000
    });
    loader.present();

this.ob = Observable.interval(20 * 60).subscribe(x => {
   this.data = this.authservice.funn();
   console.log('received', this.data);
this.loc();
   
   if(this.data.length ===1 || this.data.length > 0){ 
     this.ob.unsubscribe();
      loader.dismiss();
      this.diact();
this.navCtrl.push(HomePage);

   }else{
    
   }


  });
  
}

diact(){
this.ob.unsubscribe();
}



setlooc(lat,long,h,m,i){
  this.authservice.dropof2(lat,long,h,m,i);
}

 async loc(){
   await this.platform.ready();
     this.geolocation.getCurrentPosition().then((position) => {
        this.setlooc(position.coords.latitude, position.coords.longitude,this.h,this.m,this.i);
        console.log(position.coords.latitude, position.coords.longitude);
     });
this.locationAccuracy.canRequest().then((canRequest: boolean) => {
  if(canRequest) {
    // the accuracy option will be ignored by iOS
    this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      () => console.log('Request successful'),
      error => console.log('Error requesting location permissions', error)
    );
  }
});
}


obb:any=[];
i:number=0;
h:number=0;
m:number=0;

timee(){ 
this.obb = Observable.interval(1000).subscribe(x => {
this.i++;
if(this.i ==60){
  this.i=0;
  this.m++;
 if(this.m ==60){
  this.m=0;
  this.h++;
 }
}else{

}
   });
}


diac(){
this.obb.unsubscribe();
}


}


