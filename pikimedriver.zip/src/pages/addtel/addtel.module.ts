import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddtelPage } from './addtel';

@NgModule({
  declarations: [
    AddtelPage,
  ],
  imports: [
    IonicPageModule.forChild(AddtelPage),
  ],
})
export class AddtelPageModule {}
