//import { HttpClient } from '@angular/common/http';
import {Http ,Response } from '@angular/http';
import { Injectable , } from '@angular/core';
import 'rxjs/Rx';
import { Storage } from '@ionic/storage';

@Injectable()
export class AuthServiceProvider {

  constructor(private storage: Storage , private http: Http ) {
   this.getiid();
    this.getiid();
  }
carti = [];

url ='https://pikime.000webhostapp.com/piki';
//url = 'http://127.0.0.1/piki';

tell:string;
tom(tel){
this.tell = tel ;
}

tomget(){
  return this.tell;
}

plat:string;
plong:string;
pplace:string;
dlat:string;
dlong:string;
dplace:string;

id:string='1';
indexx :string;

getiid(){
  this.storage.get('index').then((val) => {
    console.log('indexs = ', val);
this.indexx = val;
console.log(this.indexx);
  });
  if(this.indexx==null || this.indexx =='0'){
    this.indexx = this.ind ;
  }else{

  }
  return this.indexx;
}
ind:string;
idex(id){
this.ind = id;
console.log('---------sss'+this.ind);
}

place(){
   return this.pplace;
}

dlace(){
    return this.dplace;
}

pickup(lat,long,place){
console.log('pickup - ' +lat,long,place);
this.plat=lat;
this.plong = long;
this.pplace = place;
  console.log('pick off  - ' +this.plat,this.plong,this.pplace);
}
dist:any=[];
dropof(lat ,long ,place){

  console.log('drop off  - ' +lat,long,place);
this.dlat=lat;
this.dlong = long;
this.dplace = place;

}
getdistt(){
return this.dist;
}

indexxt:string;
send(){
    this.storage.get('index').then((val) => {
    console.log('index', val);
    this.indexxt = val;
  if(this.indexx==null || this.indexx =='0'){
    this.indexxt = this.ind ;
    console.log('ind set -'+this.indexxt);
  }else{
console.log('ind set not set -');
  }
     this.request(this.indexxt,this.plat,this.plong,this.pplace,this.dlat,this.dlong,this.dplace).subscribe(
      (response) => response,
      (error) =>console.log(error));})
}

getp(){
    this.storage.get('index').then((val) => {
    console.log('profile -', val);
    this.indexxt = val;
     if(this.indexxt==null || this.indexxt =='0'){
    this.indexxt = this.ind ;
    console.log('ind set -'+this.indexxt);
  }else{
console.log('ind set not set -');
  }
    });
}



getdist(){
   return this.http.get(this.url+'/dist.php?lat1='+this.plat+'&long1='+this.plong+'&lat2='+this.dlat+'&long2='+this.dlong).map(
     (response : Response) => {
  const data = response.json();
  return data;});} 


check(numb){
   return this.http.get(this.url+'/api/checklogin.php?number='+numb).map((response : Response) => {
  const data = response.json();return data;});} 

toj:any;
pinfo(numb,name, email){
  console.log(numb ,name ,email);
   return  this.http.get(this.url+'/api/updatep.php?number='+numb+'&name='+name+'&email='+email).map((response : Response) => {
  const data = response.json();return data;});
} 

prof(numb){
   return this.http.get(this.url+'/api/prof.php?id='+numb).map((response : Response) => {
  const data = response.json();return data;});} 
hnumb:number;
hnumset(id){
  this.hnumb = id;
}
request(id,plat , plong ,pplace ,dlat , dlong , dplace){
   return this.http.get(this.url+'/api/request.php?id='+id+'&plat='+plat+'&plong='+plong+'&pplace='+pplace+'&dlat='+dlat+'&dlong='+dlong+'&dplace='+dplace+'&hnumb='+this.hnumb).map((response : Response) => {
  const data = response.json();return console.log(data);});} 

updatel(email,tel){
   return this.http.get(this.url+'/api/updatetel.php?email='+email+'&tel='+tel).map((response : Response) => {
  const data = response.json();return data;});} 

getid(numb){
   return this.http.get(this.url+'/api/getid.php?id='+numb).map((response : Response) => {
  const data = response.json();return data;});} 

getprof(){
     if(this.indexx==null || this.indexx =='0'){
    this.indexx = this.ind ;
    console.log('ind set -'+this.indexx);
  }else{
console.log('ind set not set -');
  }
   return this.http.get(this.url+'/api/menu/profile.php?id='+this.indexx).map((response : Response) => {
  const data = response.json();return data;});} 


 vcode(numb){
   return this.http.get(this.url+'/api/getvcode.php?id='+numb).map((response : Response) => {
  const data = response.json();return data;});}  

getdriver(){
   return this.http.get(this.url+'/api/driver/rrrequest.php?id='+this.indexx).map((response : Response) => {
  const data = response.json();return data;});} 

  getfinal(){
   return this.http.get(this.url+'/distt.php?id=121').map((response : Response) => {
  const data = response.json();return data;});} 

cdriver(){
   return this.http.get(this.url+'/api/driver/cancel.php?id='+this.indexx).map((response : Response) => {
  const data = response.json();return data;});} 


topup(tell,amntt){
   return this.http.get(this.url+'/api/money/topup.php?tell='+tell+'&amount='+amntt).map((response : Response) => {
  const data = response.json();return data;});} 

cstart(){
   return this.http.get(this.url+'/api/driver/cstart.php?id='+this.indexx).map((response : Response) => {
  const data = response.json();return data;});} 

cend(){
   return this.http.get(this.url+'/api/driver/cend.php?id='+this.idrr).map((response : Response) => {
  const data = response.json();return data;});} 

verif(numb){
   return this.http.get(this.url+'/api/sendsms.php?number='+numb).map((response : Response) => {
const data = response.json();return data;});} 



fblogin(email,name,pic){
	 return this.http.get(this.url+'/api/fblogin.php?email='+email+'&name='+name+'&pic='+pic)
.map((response : Response) => {const data = response.json();return data;});} 



direction(ddlat,ddlong){
return this.http.get(this.url+'/directions.php?plat='+this.plat+'&plong='+this.plong+'&dlat='+ddlat+'&dlong='+ddlong)
.map((response : Response) => {const data = response.json();return data;});
}

fbloginn(email,name,pic){
	 return this.http.get(this.url+'/api/fblogin.php?email='+email+'&name='+name+'&pic='+pic)
.map((response : Response) => {const data = response.json();return data;});
} 
  
  customers(param , para2 , para3){
   return this.http.get(this.url+'/api/customer.php?categ='+param + '&para2='+para2 + '&para3='+para3 )
.map((response : Response) => {const data = response.json();
return data;});} 


   message(param){
   return this.http.get(this.url+'/api/message.php?categ='+param).map(
 (response : Response) => {const data = response.json();return data;});} 


  notification(){
   return this.http.get(this.url+'/api/notification.php').map( (response : Response) => { const data = response.json();
return data;});} 




bala(){
   if(this.indexx==null || this.indexx =='0'){
    this.indexx = this.ind ;
    console.log('ind set -'+this.indexx);
  }else{
console.log('ind set not set -');
  }
   console.log('ind set issss -'+this.indexx);
   return this.http.get(this.url+'/api/money/balance.php?id='+this.indexx+'&type=c').map((response : Response) => {
const data = response.json();return data;});} 

journey(){
   return this.http.get(this.url+'/api/money/jctransfer.php?id='+this.indexx+'&type=c').map((response : Response) => {
const data = response.json();return data;});} 

sent(){
   return this.http.get(this.url+'/api/money/stransfer.php?id='+this.indexx+'&type=c').map((response : Response) => {
const data = response.json();return data;});} 

received(){
   return this.http.get(this.url+'/api/money/rtransfer.php?id='+this.indexx+'&type=c').map((response : Response) => {
const data = response.json();return data;});}

cash:string;
dtel:string;

setcash(cash){
this.cash = cash;
console.log('my cash -', this.cash);
}

setdrtell(tell){
  this.dtel =tell;
  console.log('dr tell - ' , this.dtel);
}

getcash(){
  return this.cash;
}

transfer(){
  console.log('details -  -  -ccc ' , this.indexx , this.cashh , this.dtel);
   return this.http.get(this.url+'/api/money/transfer.php?ids='+this.indexx+'&tps=c'+'&amnt='+this.cashh+'&tell='+this.dtel+'&tt=j').map((response : Response) => {
const data = response.json();return data;});}

transferr(){
  console.log('details -  -  -ccc ' , this.indexx , this.cashh , this.dtel);
   return this.http.get(this.url+'/api/money/jtransfer.php?ids='+this.indexx+'&tps=c'+'&amnt='+this.cashh+'&tell='+this.dtel+'&tt=j').map((response : Response) => {
const data = response.json();return data;});}

transfcash(){
  console.log('details -  -  -//// ' , this.indexx , this.cashh , this.dtel);
   return this.http.get(this.url+'/api/money/ccashd.php?amnt='+this.cashh+'&tell='+this.dtel+'&tt=j').map((response : Response) => {
const data = response.json();return data;});}  

trans(tell,amnt){
    console.log('details -  -  - ' , this.indexx , tell , amnt);
   return this.http.get(this.url+'/api/money/transfer.php?ids='+this.indexx+'&tps=c'+'&amnt='+amnt+'&tell='+tell+'&tt=t').map((response : Response) => {
const data = response.json();return data;});} 


cashh:string;
type:string;
time:string;
km:string;

yom(type , cashh , time,km){
this.type= type;
this.cashh = cashh;
this.time= time;
this.km = km;
console.log(this.cashh , this.type,this.time,this.km);
} 

idrr:number;
setidr(idr){
  this.idrr = idr ;
  console.log('-----------------------------'+this.idrr +'---'+idr);
  console.log(this.idrr);
}







}
