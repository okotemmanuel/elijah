import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , Platform} from 'ionic-angular';
import { Ionic2RatingModule } from "ionic2-rating";
import { HomePage } from '../home/home';
 import { AuthServiceProvider } from '../../providers/service/service';
import {Observable} from 'rxjs';
import { Geolocation } from '@ionic-native/geolocation';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
/**
 * Generated class for the PayPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
declare var google: any;
@IonicPage()
@Component({
  selector: 'page-pay',
  templateUrl: 'pay.html',
})
export class PayPage {
    geocoder: any;

  constructor(private platform:Platform,private locationAccuracy: LocationAccuracy,private authservice : AuthServiceProvider,public navCtrl: NavController, public navParams: NavParams ,public geolocation: Geolocation ) {
this.getamt();   
this.geocoder = new google.maps.Geocoder;
this.loc();
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad PayPage');
  }


set(){
  this.navCtrl.push(HomePage);
}
cash:string;
getamt(){
  this.cash = this.authservice.cashh;
  console.log(this.cash);
}
ob:any=[];
data:any=[];
bal:string;
mess:string;
t:number=0;

setlooc(lat,long,place){
  //console.log(lat,long,place);
  this.authservice.pickup(lat,long,place);

}
 async loc(){
   await this.platform.ready();
     this.geolocation.getCurrentPosition().then((position) => {
        this.setlooc(position.coords.latitude, position.coords.longitude,'');
        console.log('----------'+position.coords.latitude, position.coords.longitude);
     });

this.locationAccuracy.canRequest().then((canRequest: boolean) => {

  if(canRequest) {
    // the accuracy option will be ignored by iOS
    this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      () => console.log('Request successful'),
      error => console.log('Error requesting location permissions', error)
    );
  }

});

}

pay(){
  if(this.t==0){ 
  this.data = this.authservice.transfer().subscribe((response) =>this.bal = response,(error) =>console.log(error));
  this.ob = Observable.interval(20 * 60).subscribe(x => {
 if(this.bal.length < 1 || this.bal==undefined || this.bal==null){ 
   }else{
       if(this.bal=='1'){
   this.mess ='SUCCESSFULLY PAID';
    this.t=1;
   this.diact();
       }
else if(this.bal=='0'){
this.mess ='ERROR insufficient balance Or Tell is not registered';
       }
       else{
         this.mess='unknown eror';
       }
     console.log(this.bal);         
      }
   })
}else{
   this.mess ='ALREADY PAID';
}

}

diact(){
this.ob.unsubscribe();
}

}
