import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {Observable} from 'rxjs';
import { AuthServiceProvider } from '../../providers/service/service';
import { PayPage } from '../pay/pay';

/**
 * Generated class for the JstartPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-jstart',
  templateUrl: 'jstart.html',
})
export class JstartPage {

  constructor(private authservice : AuthServiceProvider,public navCtrl: NavController, public navParams: NavParams) {
    
    this.timee();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad JstartPage');
  }

obtt:any=[];
dat:any=[];
tom:any=[];
ob:any=[];
i:number=0;
h:number=0;
m:number=0;
ofb:any;
timee(){
  
   this.ofb = Observable.interval(1000).subscribe(x => {
this.i++;
if(this.i ==60){
  this.i=0;
  this.getend();
  this.m++;
 if(this.m ==60){
  this.m=0;
  this.h++;
 }
}else{

}
   });
}
diac(){
this.ob.unsubscribe();
}
obtty:any;
getend(){
  var t=0;
 this.obtty = Observable.interval(20 * 60).subscribe(x => {
   this.dat= this.authservice.cend().subscribe(
      (response) => console.log(this.tom = response),
      (error) =>console.log(error));
 if(this.tom==1){

console.log('great = ', this.tom);
if(t===2){
this.navCtrl.push(PayPage);
this.ofb.unsubscribe();
this.obtty.unsubscribe();
}else{
t++;
}

 }
 else{
   console.log('try = ', this.tom);}}
   );
}

diact(){
this.obtt.unsubscribe();
}



}
