import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TopupPage } from './topup';

@NgModule({
  declarations: [
    TopupPage,
  ],
  imports: [
    IonicPageModule.forChild(TopupPage),
  ],
})
export class TopupPageModule {}
