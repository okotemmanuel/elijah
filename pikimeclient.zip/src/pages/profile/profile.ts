import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

 import { AuthServiceProvider } from '../../providers/service/service';
import {Observable} from 'rxjs';
import { Storage } from '@ionic/storage';
@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})

export class ProfilePage {

  constructor(private storage: Storage ,private authservice : AuthServiceProvider ,public navCtrl: NavController, public navParams: NavParams) {
    this.get();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProfilePage');
  }
  indexx:any;
  tom:any=[];
data:any=[];
ob:any=[];
index2:boolean=false;
get(){
 this.ob = Observable.interval(20 * 60).subscribe(x => {
  this.data = this.authservice.getprof().subscribe((response) =>this.tom = response,(error) =>console.log(error));
   if(this.tom.length < 1 || this.tom ===undefined || this.tom===null){ 
   }else{
        this.diact();
        this.index2=true;
        console.log('reced', this.tom);
   }
  });
}

diact(){
this.ob.unsubscribe();
}


}

