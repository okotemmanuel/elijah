//import { HttpClient } from '@angular/common/http';
import {Http ,Response} from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';
import {Observable} from 'rxjs'
import { Storage } from '@ionic/storage';

@Injectable()
export class AuthServiceProvider {
public indexxs;
  constructor(private http: Http ,  public storage: Storage) {
   this.getidd();
 
  }
carti = [];

url ='https://pikime.000webhostapp.com/piki';
//url = 'http://127.0.0.1/piki';

tell:string;
tom(tel){
this.tell = tel ;
}
n:any;
public indexx:string;

getidd(){
this.n = this.storage.get('index').then((val) => {
  console.log('indexserv = ', val);
this.indexxs = val;
  if(this.indexxs==null || this.indexxs =='0'){
    this.indexxs = this.ind ;
  }else{

  }
  }); 
}

ind:string;
idex(id){
this.ind = id;
console.log('-----------------------'+this.ind);
}



dataa:any[];
setdata(data){
this.dataa = data;
}

getdata(){
  return this.dataa;
}

tomget(){
  return this.tell;
}
plat:string;
plong:string;
pplace:string;
id:string='1';
data:any=[];
pickup(lat,long,place){
console.log('pickup - ' +lat,long,place);
this.plat=lat;
this.plong = long;
this.pplace = place;

  if(this.indexxs==null || this.indexxs =='0'){
    this.indexxs = this.ind ;
  }else{

  }
console.log('this.n - ' , this.indexxs);
this.drequest(this.indexxs,this.plat,this.plong,this.pplace).subscribe(
      (response) => this.data = response,
      (error) =>console.log(error)
);
 return this.data;
}
dat:any=[];
funn(){
   this.dat = this.pickup(this.plat,this.plong,this.pplace);
   return this.dat; 
}

idj:number;
setidj(id){
  this.idj=id;
}
dropof(lat ,long ,place){
  console.log('drop off  - ' +lat,long,place);
}

dlat:string;
dlong:string;
h:number;
m:number;
s:number;
dropof2(lat ,long ,h , m ,s){
this.dlat=lat;
this.dlong = long;
this.h = h;
this.m = m;
this.s = s;
  console.log('drop off2  - ' +lat,long,h,m,s);
  this.time= (h*60)+m;

}
time:number;
lastj(){
   return this.http.get(this.url+'/api/driver/updateactual.php?id='+this.idj+'&lat='+this.dlat+'&lng='+this.dlong+'&time='+this.time).map((response : Response) => {
  const data = response.json();return data;});} 

check(numb){
   return this.http.get(this.url+'/api/checklogin.php?number='+numb).map((response : Response) => {
  const data = response.json();return data;});} 

toj:any;
pinfo(numb,name, email){
  console.log(numb ,name ,email);
   return  this.http.get(this.url+'/api/updatep.php?number='+numb+'&name='+name+'&email='+email).map((response : Response) => {
  const data = response.json();return data;});
} 

prof(numb){
   return this.http.get(this.url+'/api/prof.php?id='+numb).map((response : Response) => {
  const data = response.json();return data;});} 

 drequest(id,plat , plong ,pplace){
   return this.http.get(this.url+'/api/driver/drequest.php?id='+this.indexxs+'&plat='+plat+'&plong='+plong+'&pplace='+pplace).map((response : Response) => {
  const data = response.json();return data;});}  

 startj(idr){
   console.log('start - '+idr);
   return this.http.get(this.url+'/api/driver/startj.php?idr='+idr).map((response : Response) => {
  const data = response.json();return data;});} 

 endj(idr){

   return this.http.get(this.url+'/api/driver/endj.php?idr='+idr).map((response : Response) => {
  const data = response.json();return data;});} 

request(id,plat , plong ,pplace ,dlat , dlong , dplace){
   return this.http.get(this.url+'/api/request.php?id='+id+'&plat='+plat+'&plong='+plong+'&pplace='+pplace+'&dlat='+dlat+'&dlong='+dlong+'&dplace='+dplace).map((response : Response) => {
  const data = response.json();return console.log(data);});} 

updatel(email,tel){
   return this.http.get(this.url+'/api/updatetel.php?email='+email+'&tel='+tel).map((response : Response) => {
  const data = response.json();return data;});} 

getid(numb){
   return this.http.get(this.url+'/api/getid.php?id='+numb).map((response : Response) => {
  const data = response.json();return data;});} 

confirm(idr){
   return this.http.get(this.url+'/api/driver/updatep.php?id='+idr+'&iddriver='+this.indexxs+'&drlat='+this.plat+'&drlong='+this.plong).map((response : Response) => {
  const data = response.json();return data;});} 

clogin(tell , pwd){
   return this.http.get(this.url+'/api/driver/checklogin.php?tell='+tell+'&pwd='+pwd).map((response : Response) => {
  const data = response.json();return data;});} 

 vcode(numb){
   return this.http.get(this.url+'/api/getvcode.php?id='+numb).map((response : Response) => {
  const data = response.json();return data;});}  

verif(numb){
   return this.http.get(this.url+'/api/sendsms.php?number='+numb)
.map(
 (response : Response) => {
         const data = response.json();
return data;
 }
);
  } 



fblogin(email,name,pic){
	 //cn='+cn+'&mn='+mn+'&mp='+mp+'&l='+l+'&vn='+vn+'&ved='+ved+'&vna='+vna
   return this.http.get(this.url+'/api/fblogin.php?email='+email+"&name ="+name+"&pic="+pic)
.map(
 (response : Response) => {
         const data = response.json();
return data;
 }
);
  } 

     

  customers(param , para2 , para3){
	 //cn='+cn+'&mn='+mn+'&mp='+mp+'&l='+l+'&vn='+vn+'&ved='+ved+'&vna='+vna


   return this.http.get(this.url+'/api/customer.php?categ='+param + '&para2='+para2 + '&para3='+para3 )
.map(
 (response : Response) => {
         const data = response.json();
return data;
 }
);
  } 


   message(param){
   return this.http.get(this.url+'/api/message.php?categ='+param)
.map(
 (response : Response) => {
         const data = response.json();
return data;
 }
);
  } 

  notification(){
   return this.http.get(this.url+'/api/notification.php')
.map(
 (response : Response) => {
         const data = response.json();
return data;
 }
);
  } 


//////////////////////////

getprof(){
  console.log(this.indexxs);
   return this.http.get(this.url+'/api/menu/dprofile.php?id='+this.indexxs).map((response : Response) => {
  const data = response.json();return data;});} 




///////money
bala(){
  console.log('id bal' , this.indexxs);
   return this.http.get(this.url+'/api/money/balance.php?id='+this.indexxs+'&type=d').map((response : Response) => {
const data = response.json();return data;});} 

journey(){
   return this.http.get(this.url+'/api/money/jdtransfer.php?id='+this.indexxs+'&type=d').map((response : Response) => {
const data = response.json();return data;});} 

sent(){
   return this.http.get(this.url+'/api/money/stransfer.php?id='+this.indexxs+'&type=d').map((response : Response) => {
const data = response.json();return data;});} 

received(){
   return this.http.get(this.url+'/api/money/rtransfer.php?id='+this.indexxs+'&type=d').map((response : Response) => {
const data = response.json();return data;});}




trans(tell,amnt){
    console.log('details -  -  - ' , this.indexx , tell , amnt);
   return this.http.get(this.url+'/api/money/transfer.php?ids='+this.indexxs+'&tps=d'+'&amnt='+amnt+'&tell='+tell+'&tt=t').map((response : Response) => {
const data = response.json();return data;});
} 





}
