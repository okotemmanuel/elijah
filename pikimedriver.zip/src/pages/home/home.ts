import { Component, ViewChild, ElementRef , NgZone} from '@angular/core';
import { NavController ,LoadingController ,ToastController, AlertController ,Platform} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
 
import { SetlocPage } from '../setloc/setloc';
import { AuthServiceProvider } from '../../providers/service/service';
import { Storage } from '@ionic/storage';
import {Observable} from 'rxjs'

import { CallPage } from '../call/call';
import { LocalNotifications } from '@ionic-native/local-notifications';

declare var google: any;
 
@Component({
  selector: 'home-page',
  templateUrl: 'home.html'
})
export class HomePage {
 
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  autocomplete: any;
  GoogleAutocomplete: any;
  GooglePlaces: any;
  geocoder: any ;
  autocompleteItems: any;
  nearbyItems: any = new Array<any>();
  loading: any;
  markers: any;
  locationn:String = '';

 constructor(
    public zone: NgZone,private authservice : AuthServiceProvider,private storage: Storage ,public localNotifications: LocalNotifications,
    public loadingCtrl: LoadingController,private platform:Platform ,public alertCtrl: AlertController ,
    public navCtrl: NavController, public geolocation: Geolocation ,public toastCtrl: ToastController
  ) {
    this.markers = [];
  
    this.geocoder = new google.maps.Geocoder;
    let elem = document.createElement("div")
    this.GooglePlaces = new google.maps.places.PlacesService(elem);
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
    this.autocomplete = {
      input: ''
    };
    this.autocompleteItems = [];
    this.loading = this.loadingCtrl.create();
     //this.loadMap();
     platform.ready().then(() => {
      this.loadMap();
    });

    this.funn();
    this.index=false;
    this.noti();
}



noti(){
  //var date = new Date(this.data.date+" "+this.data.time);
    this.localNotifications.schedule({
     text: 'PICK UP CLIENT',
     //at: date,
     led: 'FF0000',
     sound: './assets/noti/noti.mp3',
     icon: './assets/imgs/icon.png'
  });
 
}



  ionViewDidLoad(){
 
}
ob:any;
data:any[];
index:boolean = false;
funn(){
//setInterval(this.fun(), 120000);
  this.ob = Observable.interval(20 * 60).subscribe(x => {
   this.data = this.authservice.funn();
   console.log('received', this.data);
   
   if(this.data.length ===1 || this.data.length ===0){
    this.index =false;
   }else{
     this.authservice.setdata(this.data);
     this.authservice.setidj(parseInt(this.data[0]));
      this.index= true;

      this.diact();
    
   }
  });
}

diact(){
this.ob.unsubscribe();
 //this.index = false ;
}



sub:string;

take(){
this.authservice.confirm(this.data[0]).subscribe(
      (response) => this.data = response,
      (error) =>console.log(error)
 );
 this.index = false ;
   this.data=[];
this.navCtrl.push(CallPage);

}

can(){
 this.index= false;
}

  updateSearchResults(){
    if (this.autocomplete.input == '') {
      this.autocompleteItems = [];
      return;
    }
    this.GoogleAutocomplete.getPlacePredictions({ input: this.autocomplete.input },
      (predictions, status) => {
        this.autocompleteItems = [];
        if(predictions){
          this.zone.run(() => {
            predictions.forEach((prediction) => {
              this.autocompleteItems.push(prediction);
            });
          });
        }
    });
  }


setlooc(lat,long,place){
  //console.log(lat,long,place);
  this.authservice.pickup(lat,long,place);

}

selectSearchResult(item){
  this.clearMarkers();
  this.autocompleteItems = [];

  this.geocoder.geocode({'placeId': item.place_id}, (results, status) => {
    if(status === 'OK' && results[0]){
      let position = {
          lat: results[0].geometry.location.lat,
          lng: results[0].geometry.location.lng
      };
   this.setlooc(results[0].geometry.location.lat().toString(), results[0].geometry.location.lng().toString(),item.description);

      let marker = new google.maps.Marker({
         animation: google.maps.Animation.DROP,
        position: results[0].geometry.location,
        map: this.map,
         draggable: true
      });

      this.markers.push(marker);
      this.lastLatLng(marker);
      this.map.setCenter(results[0].geometry.location);
      this.addcircle(this.map);
     
    }
  })
}


  clearMarkers(){
    for (var i = 0; i < this.markers.length; i++) {
      console.log(this.markers[i])
      this.markers[i].setMap(null);
    }
    this.markers = [];
}





  loadMap(){
    this.geolocation.getCurrentPosition().then((position) => {
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      let mapOptions = {
        center: latLng,
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
      this.addMarker(this.map);
       console.log('loaded');       
 this.geocoder.geocode({'location':latLng}, (results, status) => {
    this.locationn = results[0].formatted_address.toString(); 
    this.setlooc(position.coords.latitude, position.coords.longitude,this.locationn);
    return this.locationn;         
  });}, (err) => {
      console.log(err);
      console.log('connection error');
      this.mess = 'Internet connection lost';
    });
  }
 mess:string;



addMarker(map:any){
let marker = new google.maps.Marker({
  map: this.map,
   animation: google.maps.Animation.DROP,
    position: this.map.getCenter(),
    draggable: true
});
let content = "<h4> pickup location </h4>";
this.addInfoWindow(marker, content);
this.addcircle(map);
this.lastLatLng(marker);
}


LastLat:String;
LastLng: String;
setloc(){
  this.locationn ;
}


lastLatLng(marker){  
      google.maps.event.addListener(marker, 'dragend', () =>{ 
      this.LastLat= marker.position.lat();
      this.LastLng= marker.position.lng();
       var latlng = { 'lat':this.LastLat, 'lng': this.LastLng};

 this.geocoder.geocode({'location':latlng}, (results, status) => {
    this.locationn = results[0].formatted_address.toString(); 
    return this.locationn;         
  });
this.setlooc(this.LastLat,this.LastLng,this.locationn);
    console.log(this.locationn);
   this.presentToast(this.locationn);
    this.autocomplete.input = this.locationn ;});
}


 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 3000
    });
    toast.present();
  }


set(){
   this.presentToast('updated');
 // this.navCtrl.push(SetlocPage);
}

//setInterval(console.log(hello), 120000) ; 


addcircle(map:any){
let circle = new google.maps.Circle({
            strokeColor: '#28becf',
            strokeOpacity: 0.8,
            strokeWeight: 1,
            fillColor: '#28becf',
            fillOpacity: 0.35,
            map: map,
            center: this.map.getCenter(),
            radius: 150
});
}



  addInfoWindow(marker, content){
    let infoWindow = new google.maps.InfoWindow({
      content: content
    });

    google.maps.event.addListener(marker, 'click', () => {
      infoWindow.open(this.map, marker);
    });
  }





}