
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the TransferPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

import { AuthServiceProvider } from '../../providers/service/service';
import {Observable} from 'rxjs';
import {FormGroup, FormBuilder ,FormControl} from "@angular/forms";

@IonicPage()
@Component({
  selector: 'page-transfer',
  templateUrl: 'transfer.html',
})
export class TransferPage {

myForm: FormGroup;
userInfo: {tel: string, amount: string } = {tel: '', amount:''};


  constructor(private authservice : AuthServiceProvider,public formBuilder: FormBuilder , public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TransferPage');
  }

  ngOnInit(): any {
    this.myForm = this.formBuilder.group({
      'tel': new FormControl(),
      'amount': new FormControl(),
    })
  }

num:string;
onSubmit() {
 this.num = this.myForm.value.tel + this.myForm.value.amount;
 console.log('tom ---' ,this.myForm.value.tel , this.myForm.value.amount);

 if(this.t==0){ 
 this.data = this.authservice.trans(this.myForm.value.tel,this.myForm.value.amount).subscribe((response) =>this.bal = response,(error) =>console.log(error));

  this.ob = Observable.interval(20 * 60).subscribe(x => {
 if(this.bal.length < 1 || this.bal==undefined || this.bal==null){ 
   }else{
       if(this.bal=='1'){
   this.mess ='SUCCESSFULLY SENT';
    this.t=1;
   this.diact();
       }
else if(this.bal=='0'){
this.mess ='ERROR insufficient balance Or Tell is not registered';
       }
       else{
         this.mess='unknown eror';
       }
     console.log(this.bal);         
      }
   })
}else{
   this.mess ='ALREADY SENT';
}


}

ob:any=[];
data:any=[];
bal:string;
mess:string;
t:number=0;


pay(tell,amnt){

}

diact(){
this.ob.unsubscribe();
}


}
