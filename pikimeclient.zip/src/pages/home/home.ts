import { Component, ViewChild, ElementRef , NgZone} from '@angular/core';
import { NavController ,LoadingController ,ToastController, Platform ,  Searchbar , Events} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
 
import { SetlocPage } from '../setloc/setloc';
import { AuthServiceProvider } from '../../providers/service/service';
import { Storage } from '@ionic/storage';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import { RequesttPage } from '../requestt/requestt';
import {Observable} from 'rxjs';
declare var google: any;


 
@Component({
  selector: 'home-page',
  templateUrl: 'home.html'
})
export class HomePage {
 @ViewChild('mySearchbar') searchbar: Searchbar;
  @ViewChild('map') mapElement: ElementRef;
  map: any;
  autocomplete: any;
  GoogleAutocomplete: any;
  GooglePlaces: any;
  geocoder: any ;
  autocompleteItems: any;
  nearbyItems: any = new Array<any>();
  loading: any;
  markers: any;
  locationn:String = '';
  v:boolean=true;

 constructor(public events: Events,
    public zone: NgZone,private authservice : AuthServiceProvider,private storage: Storage ,
    public loadingCtrl: LoadingController,private platform:Platform,private locationAccuracy: LocationAccuracy,
    public navCtrl: NavController, public geolocation: Geolocation ,public toastCtrl: ToastController
  ) {
    this.markers = [];
  
    this.geocoder = new google.maps.Geocoder;
    let elem = document.createElement("div")
    this.GooglePlaces = new google.maps.places.PlacesService(elem);
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
    this.autocomplete = {
      input: ''
    };
  
    this.autocompleteItems = [];
    this.loading = this.loadingCtrl.create();
     //this.loadMap();
     platform.ready().then(() => {
      this.loadMap();
    });
    this.getid();
}




  ionViewDidLoad(){

}

ove(){
  this.v = false;
}

onClear(){
this.autocomplete.input='';
}



  updateSearchResults(){
    if (this.autocomplete.input == '') {
      this.autocompleteItems = [];
      return;
    }
    this.GoogleAutocomplete.getPlacePredictions({ input: this.autocomplete.input },
      (predictions, status) => {
        this.autocompleteItems = [];
        if(predictions){
          this.zone.run(() => {
            predictions.forEach((prediction) => {
              this.autocompleteItems.push(prediction);
            });
          });
        }
    });
  }


setlooc(lat,long,place){
  this.authservice.dropof(lat,long,place);
}

setcurr(lat,long,place){
  this.authservice.pickup(lat,long,place);
}

selectSearchResult(item){
  this.clearMarkers();
  this.autocompleteItems = [];

  this.geocoder.geocode({'placeId': item.place_id}, (results, status) => {
    if(status === 'OK' && results[0]){
      let position = {
          lat: results[0].geometry.location.lat,
          lng: results[0].geometry.location.lng
      };
        
      this.setlooc(results[0].geometry.location.lat().toString(), results[0].geometry.location.lng().toString(),item.description);

      let marker = new google.maps.Marker({
         animation: google.maps.Animation.DROP,
        position: results[0].geometry.location,
        map: this.map,
         draggable: true
      });
     // this.lastLatLng(marker);
      this.map.setCenter(results[0].geometry.location);
      this.addcircle(this.map);
       this.autocomplete.input = item.description;
  
    }
  })
   this.set();
}


  clearMarkers(){
    for (var i = 0; i < this.markers.length; i++) {
      console.log(this.markers[i])
      this.markers[i].setMap(null);
    }
    this.markers = [];
}

gpps(){
  this.locationAccuracy.canRequest().then((canRequest: boolean) => {
  if(canRequest) {
    this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      () => console.log('Request successful'),
      error => console.log('Error requesting location permissions', error)
    );
  }else{
    this.gpps();
  }
});
}

async loadMap(){
await this.platform.ready();

    this.geolocation.getCurrentPosition().then((position) => {
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      let mapOptions = {
        center: latLng,
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.gpps();
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
      //this.addMarker(this.map);
       console.log('loaded');       
 this.geocoder.geocode({'location':latLng}, (results, status) => {
    this.locationn = results[0].formatted_address.toString(); 
    this.setcurr(position.coords.latitude, position.coords.longitude,this.locationn);
      this.addYourLocationButton(this.map,this.map); 
this.move();
    return this.locationn;   
  });}, (err) => {
      console.log(err);
      console.log('connection error');
      this.mess = 'Internet connection lost';
    });
  }



tomj:any;
move(){ 
google.maps.event.addListener(this.map, 'dragend', () => {
    console.log('ceter',JSON.stringify(this.map.getCenter().lat()) ,JSON.stringify(this.map.getCenter().lng()) );
        this.autocomplete.input = 'loading...' ;
this.geocoder = new google.maps.Geocoder;
  var latlng = this.map.getCenter(); 
  this.geocoder.geocode({'location':latlng}, (results, status) => {
    this.locationn = results[0].formatted_address.toString(); 
    this.setlooc(JSON.stringify(this.map.getCenter().lat()),JSON.stringify(this.map.getCenter().lng()),this.locationn);
        this.autocomplete.input =  this.locationn ;
       console.log('///////////////////s'+this.locationn);   });
this.butt =  true;
console.log(this.butt);
});
  
}


butt:boolean=false;








 mess:string;
indexxt:string;
getid(){
  this.storage.get('index').then((val) => {
    console.log('indexs = ', val);
    this.indexxt = val;
    this.presentToast('id = '+this.indexxt);
  })
}
/*
addMarker(map:any){
let marker = new google.maps.Marker({
  map: this.map,
   animation: google.maps.Animation.DROP,
    position: this.map.getCenter(),
    draggable: true
});
let content = "<h4> pickup location </h4>";
this.addInfoWindow(marker, content);
this.addcircle(map);
this.lastLatLng(marker);
}
*/


setloc(){
   this.locationn = '';
}






 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 3000
    });
    toast.present();
  }


set(){
  this.navCtrl.push(RequesttPage);
}

okay(){
  this.navCtrl.push(RequesttPage);
}

addcircle(map:any){
let circle = new google.maps.Circle({
            strokeColor: '#28becf',
            strokeOpacity: 0.8,
            strokeWeight: 1,
            fillColor: '#28becf',
            fillOpacity: 0.35,
            map: map,
            center: this.map.getCenter(),
            radius: 150
});
}



  addInfoWindow(marker, content){
    let infoWindow = new google.maps.InfoWindow({
      content: content
    });

    google.maps.event.addListener(marker, 'click', () => {
      infoWindow.open(this.map, marker);
    });
  }



addYourLocationButton(map, marker) 
{
    var controlDiv = document.createElement('div');

    var firstChild = document.createElement('button');
    firstChild.style.backgroundColor = '#fff';
    firstChild.style.border = 'none';
    firstChild.style.outline = 'none';
    firstChild.style.width = '28px';
    firstChild.style.height = '28px';
    firstChild.style.borderRadius = '2px';
    firstChild.style.boxShadow = '0 1px 4px rgba(0,0,0,0.3)';
    firstChild.style.cursor = 'pointer';
    firstChild.style.marginRight = '10px';
    firstChild.style.padding = '0';
    firstChild.title = 'Your Location';
    controlDiv.appendChild(firstChild);

    var secondChild = document.createElement('div');
    secondChild.style.margin = '5px';
    secondChild.style.width = '18px';
    secondChild.style.height = '18px';
    secondChild.style.backgroundImage = 'url(https://maps.gstatic.com/tactile/mylocation/mylocation-sprite-2x.png)';
    secondChild.style.backgroundSize = '180px 18px';
    secondChild.style.backgroundPosition = '0 0';
    secondChild.style.backgroundRepeat = 'no-repeat';
    firstChild.appendChild(secondChild);

    google.maps.event.addListener(map, 'center_changed', function () {
        secondChild.style['background-position'] = '0 0';
    });

    firstChild.addEventListener('click', function () {
        var imgX = '0',
            animationInterval = setInterval(function () {
                imgX = imgX === '-18' ? '0' : '-18';
                secondChild.style['background-position'] = imgX+'px 0';
            }, 500);

        if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                map.setCenter(latlng);
                clearInterval(animationInterval);
                secondChild.style['background-position'] = '-144px 0';
            });
        } else {
            clearInterval(animationInterval);
            secondChild.style['background-position'] = '0 0';
        }
    });

    //controlDiv.index = 1;
    map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(controlDiv);
}


}