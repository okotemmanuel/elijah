import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerifPage } from './verif';

@NgModule({
  declarations: [
    VerifPage,
  ],
  imports: [
    IonicPageModule.forChild(VerifPage),
  ],
})
export class VerifPageModule {}
