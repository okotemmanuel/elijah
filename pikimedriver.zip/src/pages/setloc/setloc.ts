
import { Component, ViewChild, ElementRef , NgZone} from '@angular/core';
import { NavController ,LoadingController , ToastController} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { AuthServiceProvider } from '../../providers/service/service';
 //import { SetlocPage } from '../setloc/setloc';


declare var google;
 

//@IonicPage()
@Component({
  selector: 'page-setloc',
  templateUrl: 'setloc.html',
})
export class SetlocPage {
 
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  autocomplete: any;
  GoogleAutocomplete: any;
  GooglePlaces: any;
  geocoder: any ;
  autocompleteItems: any;
  nearbyItems: any = new Array<any>();
loading: any;
  markers: any;
locationn:String = '';


index:boolean = false;
index2 : boolean = false;

 constructor(
    public zone: NgZone,private authservice : AuthServiceProvider,
    public loadingCtrl: LoadingController,
    public navCtrl: NavController, public geolocation: Geolocation, public toastCtrl: ToastController
  ) {
    this.markers = [];
    this.geocoder = new google.maps.Geocoder;
    let elem = document.createElement("div")
    this.GooglePlaces = new google.maps.places.PlacesService(elem);
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
    this.autocomplete = {
      input: ''
    };
    this.autocompleteItems = [];
    this.loading = this.loadingCtrl.create();
}

  ionViewDidLoad(){
  this.loadMap();
}


updateSearchResults(){
    if (this.autocomplete.input == '') {
      this.autocompleteItems = [];
      return;
    }
 
    this.GoogleAutocomplete.getPlacePredictions({ input: this.autocomplete.input },
      (predictions, status) => {
        this.autocompleteItems = [];
        
        if(predictions){
          this.zone.run(() => {
            predictions.forEach((prediction) => {
              this.autocompleteItems.push(prediction);
            });
          });
        }

    });
}




setlooc(lat,long,place){
  //console.log(lat,long,place);
  this.authservice.dropof(lat,long,place);
 
}



selectSearchResult(item){
  this.clearMarkers();
  this.autocompleteItems = [];

  this.geocoder.geocode({'placeId': item.place_id}, (results, status) => {
    if(status === 'OK' && results[0]){
      let position = {
          lat: results[0].geometry.location.lat,
          lng: results[0].geometry.location.lng
      };
      let marker = new google.maps.Marker({
         animation: google.maps.Animation.DROP,
        position: results[0].geometry.location,
        map: this.map,
         draggable: true
      });
      this.setlooc(results[0].geometry.location.lat,results[0].geometry.location.lng,'home');
      this.markers.push(marker);
      this.lastLatLng(marker);
      this.map.setCenter(results[0].geometry.location);
      this.addcircle(this.map);
     
    }
  })
}
  clearMarkers(){
    for (var i = 0; i < this.markers.length; i++) {
      console.log(this.markers[i])
      this.markers[i].setMap(null);
    }
    this.markers = [];
}


 presentToast(mess) {
    const toast = this.toastCtrl.create({
      message: mess,
      duration: 3000
    });
    toast.present();
  }





  loadMap(){
    this.geolocation.getCurrentPosition().then((position) => {
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      let mapOptions = {
        center: latLng,
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
      this.addMarker(this.map);
     this.geocoder.geocode({'location':latLng}, (results, status) => {
    this.locationn = results[0].formatted_address.toString(); 
    this.setlooc(position.coords.latitude, position.coords.longitude,this.locationn);
    return this.locationn;         
  });}, (err) => {
      console.log(err);
      console.log('connection error');
    });
  }
 


addMarker(map:any){
let marker = new google.maps.Marker({
  map: this.map,
   animation: google.maps.Animation.DROP,
    position: this.map.getCenter(),
    draggable: true
});
let content = "<h4> Current location</h4>";
this.addInfoWindow(marker, content);
this.addcircle(map);
this.lastLatLng(marker);
}


LastLat:String;
LastLng: String;
setloc(){
  this.locationn = 'nakawa';
}


lastLatLng(marker){  
      
      google.maps.event.addListener(marker, 'dragend', () =>{ 
      this.LastLat= marker.position.lat();
      this.LastLng= marker.position.lng();
      var latlng = { 'lat':this.LastLat, 'lng': this.LastLng};

 this.geocoder.geocode({'location':latlng}, (results, status) => {
    this.locationn = results[0].formatted_address.toString(); 
    return this.locationn;         
  });

this.setlooc(this.LastLat,this.LastLng,this.locationn);
    console.log(this.locationn);
   this.presentToast(this.locationn);
    this.autocomplete.input = this.locationn ;
});

}



set(){
 
    //this.navCtrl.push(SetlocPage);
 this.index = true;
}

set2(){
  this.index2 = true ;
}

addcircle(map:any){
let circle = new google.maps.Circle({
            strokeColor: '#28becf',
            strokeOpacity: 0.8,
            strokeWeight: 1,
            fillColor: '#28becf',
            fillOpacity: 0.35,
            map: map,
            center: this.map.getCenter(),
            radius: 150
});
}



  addInfoWindow(marker, content){
    let infoWindow = new google.maps.InfoWindow({
      content: content
    });
    google.maps.event.addListener(marker, 'click', () => {
      infoWindow.open(this.map, marker);
    });
  }
 presentLoading() {
    const loader = this.loadingCtrl.create({
      content: "Searching Nearest Rider...",
      duration: 4000
    });
    loader.present();
    this.index = false;
    this.set2();
  }

cancle(){
  this.index = false;
}


 animateCircle(line) {  
          var count = 0;    var a= 0;
          window.setInterval(function() {
   if(a==0){
            count = (count + 1) % 200;
            var icons = line.get('icons');
            icons[0].offset = (count / 2) + '%';
           if(icons[0].offset ==='90%'){a= 1;}
            line.set('icons', icons);}  else{
      } }, 100);
      }


anima(){
  this.index2 = false;
    this.geolocation.getCurrentPosition().then((position) => {
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      let mapOptions = {
        center: latLng,
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
      this.addMarker(this.map);
   var lineSymbol = {
          path:google.maps.SymbolPath.CIRCLE,
          scale: 8,
          strokeColor: '#393'
        };
var image = {
   anchor: new google.maps.Point(0, 32),
    origin: new google.maps.Point(0, 0),
    scaledSize: new google.maps.Size(50, 50),
    size: new google.maps.Size(64, 64),
    url: "./assets/imgs/b.png"
  };
  var beachMarker = new google.maps.Marker({
    position: {lat: position.coords.latitude +0.004, lng: position.coords.longitude+0.0025},
    map: this.map,
    icon: image
  });
  var line = new google.maps.Polyline({
          path: [ {lat: position.coords.latitude + 0.004 , lng: position.coords.longitude + 0.0025 } , { lat: position.coords.latitude, lng: position.coords.longitude} ],
          icons: [{
            icon:lineSymbol,
            offset: '100%'
          }],
          map: this.map
        });
 this.animateCircle(line);
    }, (err) => {
      console.log(err);
      console.log('connection error');
    });
  }
 

}