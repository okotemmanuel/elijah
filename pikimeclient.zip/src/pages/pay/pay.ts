import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , Platform} from 'ionic-angular';
import { HomePage } from '../home/home';
 import { AuthServiceProvider } from '../../providers/service/service';
import {Observable} from 'rxjs';
import { Geolocation } from '@ionic-native/geolocation';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the PayPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
declare var google: any;
@IonicPage()
@Component({
  selector: 'page-pay',
  templateUrl: 'pay.html',
})
export class PayPage {
    geocoder: any;

  constructor(private storage: Storage ,private platform:Platform,private locationAccuracy: LocationAccuracy,private authservice : AuthServiceProvider,public navCtrl: NavController, public navParams: NavParams ,public geolocation: Geolocation ) {
this.getamt();   
this.geocoder = new google.maps.Geocoder;
this.loc();
/*this.datt[0]='loading';
this.datt[1]='loading';
this.datt[2]='loading';
this.datt[3]='loading';
this.datt=[];*/

this.getfinal();
//this.cashd();
  this.storage.set('state',this.st );
}
st:String='pay';
  ionViewDidLoad() {
    console.log('ionViewDidLoad PayPage');
  }


set(){
    this.storage.set('state', null );
  this.navCtrl.push(HomePage);
}
cash:string;
getamt(){

  this.cash = this.authservice.cashh;
  console.log(this.cash);
}
ob:any=[];
data:any=[];
bal:string;
mess:string;
t:number=0;
obf:any;
//datt:any;
estc:string;
estd:string;
estt:string;
act:boolean=false;
setlooc(lat,long,place){
  //console.log(lat,long,place);
  this.authservice.pickup(lat,long,place);

}
 async loc(){
   await this.platform.ready();
     this.geolocation.getCurrentPosition().then((position) => {
        this.setlooc(position.coords.latitude, position.coords.longitude,'');
        console.log('--'+position.coords.latitude, position.coords.longitude);
     });

this.locationAccuracy.canRequest().then((canRequest: boolean) => {

  if(canRequest) {
    // the accuracy option will be ignored by iOS
    this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      () => console.log('Request successful'),
      error => console.log('Error requesting location permissions', error)
    );
  }
});
}
p=0;
pay(){
  if(this.p==0){ 
  this.data = this.authservice.transferr().subscribe((response) =>this.bal = response,(error) =>console.log(error));
  this.ob = Observable.interval(20 * 60).subscribe(x => {
 if(this.bal.length < 1 || this.bal==undefined || this.bal==null){ 
   }else{
       if(this.bal=='1'){
  // this.mess ='SUCCESSFULLY PAID';
   this.diact();
       }
else if(this.bal=='0'){

       }
       else{
    
       }
     console.log(this.bal);         
      }
   });
     this.p++;
}else{
 
}

}
k=0;

cashd(){

  if(this.k==0){ 
  this.data = this.authservice.transfcash().subscribe((response) =>this.bal = response,(error) =>console.log(error));
  this.ob = Observable.interval(20 * 60).subscribe(x => {
 if(this.bal.length < 1 || this.bal==undefined || this.bal==null){ 
   
   }else{
       if(this.bal==='1'){this.diact();}
else if(this.bal=='0'){}
       else{ }
     console.log(this.bal);         
      }
   });
this.k++;
}else{}
}

diact(){
this.ob.unsubscribe();
}

typ:string;
tt:any=[];
cah:boolean=false;
cred:boolean=false;
getfinal(){
var t=0;
this.tt = [];

  this.obf = Observable.interval(20 * 60).subscribe(x => {
      this.authservice.getfinal().subscribe(
      (response) => console.log(this.tt = response),
      (error) =>console.log(error));
      this.estc = this.authservice.cash;
       this.typ = this.authservice.type;
       console.log('00-'+this.typ);
    
      this.estt = this.authservice.time;
      this.estd = this.authservice.km;
 if(this.tt.length < 1 || this.tt===undefined || this.tt===null){ 
   }else{
    this.act=true;
    console.log('-------'+t)
     console.log(this.tt);  
        if(this.typ =='cash'){
          this.cah = true;
          this.authservice.cashh = this.tt[1];
           this.cashd();
       }else if(this.typ =='credit'){
   this.cred = true;
   this.authservice.cashh = this.tt[1];
    this.pay();
       }else{

       }
    if(t==3){
   
 this.obf.unsubscribe(); 
   
    }else{
t++;
    }
          
      }
   })
}





onee:String='star-outline';
twoo:String='star-outline';
threee:String='star-outline';
fourr:String='star-outline';
fivee:String='star-outline';
o:number=0;tv:number=0;tr:number=0;fr:number=0;fv:number=0;
rating:number;
one(){
if(this.o==0){
this.onee = 'star';
this.rating=1;
this.o=1;
  }else{
    this.o =0;
   this.onee = 'star-outline';
    this.twoo = 'star-outline';
    this.threee = 'star-outline';
    this.fourr = 'star-outline';
    this.fivee = 'star-outline';
    this.rating=0;
  }

}
two(){
if(this.tv==0){
this.onee = 'star';
this.twoo = 'star';
this.rating=2;
this.tv=1;
this.rating=0;
  }else{
    this.tv =0;
 this.onee = 'star-outline';
    this.twoo = 'star-outline';
    this.threee = 'star-outline';
    this.fourr = 'star-outline';
    this.fivee = 'star-outline';
  }
}

three(){
if(this.tr==0){
this.onee = 'star';
this.twoo = 'star';
this.threee = 'star';
this.rating=3;
this.tr=1;
  }else{
    this.tr =0;
   this.onee = 'star-outline';
    this.twoo = 'star-outline';
    this.threee = 'star-outline';
    this.fourr = 'star-outline';
    this.fivee = 'star-outline';
    this.rating=0;
  }
}

four(){
if(this.fr==0){
this.onee = 'star';
this.twoo = 'star';
this.threee = 'star';
this.fourr = 'star';
this.fr=1;
this.rating=4;
  }else{
    this.fr =0;
   this.onee = 'star-outline';
    this.twoo = 'star-outline';
    this.threee = 'star-outline';
    this.fourr = 'star-outline';
    this.fivee = 'star-outline';
    this.rating=0;
  }

}

five(){
if(this.fv==0){
this.onee = 'star';
this.twoo = 'star';
this.threee = 'star';
this.fourr = 'star';
this.fivee = 'star';
this.fv=1;
this.rating=5;
  }else{
    this.fv =0;
    this.onee = 'star-outline';
    this.twoo = 'star-outline';
    this.threee = 'star-outline';
    this.fourr = 'star-outline';
    this.fivee = 'star-outline';
    this.rating=0;
  }

}



}
