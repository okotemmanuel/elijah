import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the PayinfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import { TransferPage } from '../transfer/transfer';
 import { AuthServiceProvider } from '../../providers/service/service';
import {Observable} from 'rxjs';
@IonicPage()
@Component({
  selector: 'page-payinfo',
  templateUrl: 'payinfo.html',
})
export class PayinfoPage {

index:boolean=true;
index2:boolean=false;
  constructor(private authservice : AuthServiceProvider,public navCtrl: NavController, public navParams: NavParams) {
this.get();  
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad PayinfoPage');
  }

  indexx:any;
  tom:any=[];
  bal:any=[];
 jor:any=[];
sent:any=[];
  rec:any=[];

data:any=[];
ob:any=[];
jorr:any=[];
// this.jor.length < 1 ||  this.sent.length < 1 ||
/*
  this.jor===undefined || this.jor===null ,
   this.sent===undefined || this.sent===null 
*/
get(){
 this.ob = Observable.interval(20 * 60).subscribe(x => {
  this.data = this.authservice.bala().subscribe((response) =>this.bal = response,(error) =>console.log(error));
   this.data = this.authservice.journey().subscribe((response) =>this.jor = response,(error) =>console.log(error));
    this.data = this.authservice.sent().subscribe((response) =>this.sent = response,(error) =>console.log(error));
     this.data = this.authservice.received().subscribe((response) =>this.rec = response,(error) =>console.log(error));
   if(this.bal.length < 1 || this.bal===undefined || this.bal===null){ 
   }else{
        this.diact();
        this.index2=true;
        this.index=false;
        this.jorr = this.jor[0];
        console.log('balance', this.bal[0]);
        console.log('journey', this.jor);
        console.log('sent', this.sent);
        console.log('received', this.rec);
   }
  });
}

diact(){
this.ob.unsubscribe();
}

send(){
  this.navCtrl.push(TransferPage);
}

}
