import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditprofPage } from './editprof';

@NgModule({
  declarations: [
    EditprofPage,
  ],
  imports: [
    IonicPageModule.forChild(EditprofPage),
  ],
})
export class EditprofPageModule {}
