import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,AlertController} from 'ionic-angular';

/**
 * Generated class for the TransferPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

import { AuthServiceProvider } from '../../providers/service/service';
import {Observable} from 'rxjs';
import {FormGroup, FormBuilder ,FormControl} from "@angular/forms";

@IonicPage()
@Component({
  selector: 'page-transfer',
  templateUrl: 'transfer.html',
})
export class TransferPage {

myForm: FormGroup;
userInfo: {tel: string, amount: string } = {tel: '', amount:''};


  constructor(public alertCtrl: AlertController , private authservice : AuthServiceProvider,public formBuilder: FormBuilder , public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TransferPage');
  }

  ngOnInit(): any {
    this.myForm = this.formBuilder.group({
      'tel': new FormControl(),
      'amount': new FormControl(),
    })
  }


ob:any=[];
data:any=[];
bal:any=[];
mess:string;
t:number=0;

num:string;
tell:string;
amount:string;

onSubmit() {
  var a = 0;
 console.log('tom ---' ,this.myForm.value.tel , this.myForm.value.amount);
 //this.pay(this.myForm.value.tel ,this.myForm.value.amount );
this.tell = this.myForm.value.tel;
this.amount = this.myForm.value.amount ;
this.showConfirm();
}




pay(){

    if(this.t==0){
// 
  this.data = this.authservice.trans(this.tell,this.amount).subscribe((response) =>this.bal = response,(error) =>console.log(error));
  //this.mess ='SUCCESSFULLY SENT';
  this.ob = Observable.interval(20 * 60).subscribe(x => {
 if(this.bal.length < 1 || this.bal==undefined || this.bal==null){ 
   }else{
       if(this.bal=='1'){
   this.mess ='SUCCESSFULLY SENT';
    this.t=1;
   this.diact();
       }
else if(this.bal=='0'){
this.mess ='ERROR insufficient balance Or Tell is not registered';
 //this.diact();
       }
       else{
         this.mess='unknown eror';
        //  this.diact();
       }
     console.log(this.bal);         
      }
   })
}else{
   this.mess ='ALREADY SENT';
}

}

diact(){
this.ob.unsubscribe();
}




  showConfirm() {
    const confirm = this.alertCtrl.create({
      title: 'CONFRIRMATION',
      message: 'Do you agree to send '+this.amount+' to '+this.tell , 
      buttons: [
        {
          text: 'Cancel',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Okay',
          handler: () => {
            this.pay();
          }
        }
      ]
    });
    confirm.present();
  }



}
