import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the ServicesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import {Observable} from 'rxjs';
import { AuthServiceProvider } from '../../providers/service/service';
@IonicPage()
@Component({
  selector: 'page-services',
  templateUrl: 'services.html',
})
export class ServicesPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, private authservice : AuthServiceProvider) {
    this.get();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ServicesPage');
  }
tom:any=[];
data:any=[];
ob:any;
conent:String='Loading';
indeg:boolean=false;
ind:boolean=true;
get(){
  var e=1;
 this.ob = Observable.interval(20 * 60).subscribe(x => {
  this.data = this.authservice.history().subscribe((response) =>this.tom = response,(error) =>console.log(error));
if(this.tom.length < 1 || this.tom ===undefined || this.tom===null){ 
    if(e==5){ this.conent = 'No history';this.diact(); }else{
     e++;
   }
   }else{
        this.diact();
this.ind = false;
this.indeg = true;
        console.log('reced', this.tom);
   }
  });
}

diact(){
this.ob.unsubscribe();
}




}
