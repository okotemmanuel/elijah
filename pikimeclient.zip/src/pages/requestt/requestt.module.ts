import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RequesttPage } from './requestt';

@NgModule({
  declarations: [
    RequesttPage,
  ],
  imports: [
    IonicPageModule.forChild(RequesttPage),
  ],
})
export class RequesttPageModule {}
