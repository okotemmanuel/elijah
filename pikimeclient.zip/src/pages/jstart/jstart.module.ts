import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JstartPage } from './jstart';

@NgModule({
  declarations: [
    JstartPage,
  ],
  imports: [
    IonicPageModule.forChild(JstartPage),
  ],
})
export class JstartPageModule {}
