import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {Observable} from 'rxjs';
import { AuthServiceProvider } from '../../providers/service/service';
import { PayPage } from '../pay/pay';

/**
 * Generated class for the JstartPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-jstart',
  templateUrl: 'jstart.html',
})
export class JstartPage {

  constructor(private authservice : AuthServiceProvider,public navCtrl: NavController, public navParams: NavParams) {
    this.getend();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad JstartPage');
  }

obtt:any=[];
dat:any=[];
tom:any=[];

getend(){
 this.obtt = Observable.interval(20 * 60).subscribe(x => {
   this.dat= this.authservice.cend().subscribe(
      (response) => console.log(this.tom = response),
      (error) =>console.log(error));
 if(this.tom===1){
this.diact();
console.log('great = ', this.tom);
this.navCtrl.push(PayPage);
 }
 else{
   console.log('try = ', this.tom);}}
   );
}

diact(){
this.obtt.unsubscribe();
}



}
